/********************************************************************
 Purpose:	interface for the Scb2Test class.
*********************************************************************/
#if !defined _SCB2TEST_H_
#define _SCB2TEST_H_

#include "BaseAll.h"

class Scb2Test : public CBaseAll  
{
public:
	Scb2Test();
	virtual ~Scb2Test();
	void Test();
private:
	CK_RV GenerateKey();
	CK_RV crypt_Single();
	CK_RV crypt_Update();
	
private:
	CK_OBJECT_HANDLE m_hKey;
};

#endif // _SCB2TEST_H_
