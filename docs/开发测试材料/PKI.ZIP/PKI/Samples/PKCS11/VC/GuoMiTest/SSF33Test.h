/********************************************************************
Purpose:	interface for the Ssf33Test class.
*********************************************************************/
#if !defined _SSF33TEST_H_
#define _SSF33TEST_H_

#include "BaseAll.h"

class Ssf33Test : public CBaseAll  
{
public:
	Ssf33Test();
	virtual ~Ssf33Test();
	void Test();
private:
	CK_RV GenerateKey();
	CK_RV crypt_Single();
	CK_RV crypt_Update();
	
private:
	CK_OBJECT_HANDLE m_hKey;
};

#endif // _SSF33TEST_H_