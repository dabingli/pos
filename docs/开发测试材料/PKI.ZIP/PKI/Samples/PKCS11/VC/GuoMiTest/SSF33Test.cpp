#include "Ssf33Test.h"
#define DATA_SIZE	32
#define BLOCK_SIZE	20
#define DEC_BLOCK_SIZE	16

Ssf33Test::Ssf33Test()
{
	m_hKey = 0;
}

Ssf33Test::~Ssf33Test()
{
}

void Ssf33Test::Test()
{
	if(CKR_OK != BaseAllStart())
	{
		return;
	}
	if(CKR_OK != GenerateKey())
	{
		return;
	}
	if (CKR_OK != crypt_Single())
	{
		return;
	}
	if (CKR_OK != crypt_Update())
	{
		return;
	}
}

CK_RV Ssf33Test::GenerateKey()
{
	do{
		cout<<"Generate Ssf33 key to test..."<<endl;
		CK_OBJECT_CLASS oClass = CKO_SECRET_KEY;
		CK_KEY_TYPE keyType = CKK_SSF33; 
		CK_BBOOL bTrue = true;
		CK_BBOOL bFalse = false;
		CK_ULONG ulLen = 16;
		CK_MECHANISM mechanism = {CKM_SSF33_KEY_GEN, NULL_PTR, 0};
		CK_ATTRIBUTE Ssf33tem[] = {
			{CKA_CLASS, &oClass, sizeof(CK_OBJECT_CLASS)},
			{CKA_KEY_TYPE, &keyType, sizeof(CK_KEY_TYPE)},
			{CKA_TOKEN, &bFalse, sizeof(CK_BBOOL)},
			{CKA_PRIVATE, &bTrue, sizeof(CK_BBOOL)},
			{CKA_ENCRYPT, &bTrue, sizeof(CK_BBOOL)},
			{CKA_DECRYPT, &bTrue, sizeof(CK_BBOOL)},
			{CKA_VALUE_LEN, &ulLen, sizeof(CK_ULONG)},
		};
		CK_ULONG ulCount = sizeof(Ssf33tem)/sizeof(CK_ATTRIBUTE);
		cout<<"generate SSF33 key";
		CK_RV rv = C_GenerateKey(m_hSession, &mechanism, Ssf33tem, ulCount, &m_hKey); 
		CHECK_OP(rv)
	}while(0);
	return CKR_OK;
}

CK_RV Ssf33Test::crypt_Single()
{
	CK_RV rv = CKR_OK;
	const CK_ULONG DATA_LENGTH = 1024*3;
	CK_BYTE bIn[DATA_LENGTH] = {0}, bTemp[DATA_LENGTH] = {0}, bOut[DATA_LENGTH] = {0};
	CK_ULONG ulIn = 0, ulOut = 0, ulTemp = 0;
	CK_ULONG Mechanism[3] = {CKM_SSF33_CBC, CKM_SSF33_ECB, CKM_SSF33_CBC_PAD};
	CK_BYTE_PTR bHint[3] = {(CK_BYTE_PTR)"CKM_SSF33_CBC: ",\
							(CK_BYTE_PTR)"CKM_SSF33_ECB: ",\
							(CK_BYTE_PTR)"CKM_SSF33_CBC_PAD: "};
	cout<<"SSF33: C_Encrypt/C_Decrypt: "<<endl;
	for(int i=0;i<3;i++)
	{
		for (i != 2 ? ulIn = SSF33_BLOCK_LEN : ulIn = 0; ulIn < 32; i != 2 ? ulIn += SSF33_BLOCK_LEN : ++ulIn)
		{
			for(register CK_ULONG i0 = 0;i0<ulIn;i0++)
				bIn[i0] = (CK_BYTE)i0;		
			cout<<bHint[i]<<endl;
			CK_BYTE iv[16] = {'*','2','1','0','4','z','y','b','*','2','1','0','4','z','y','b'};
			CK_MECHANISM ckMechanism = {Mechanism[i], iv, 16};
			cout<<"Encrypting initialize";
			rv = C_EncryptInit(m_hSession, &ckMechanism, m_hKey); 
			CHECK_OP(rv)
				
			cout<<"C_Encrypt[get buffer's size]";
			rv = C_Encrypt(m_hSession, bIn, ulIn, NULL, &ulTemp);
			CHECK_OP(rv)
				
			cout<<"Encrypt the message";
			rv = C_Encrypt(m_hSession, bIn, ulIn, bTemp, &ulTemp);
			CHECK_OP(rv)
			cout<<"Data encrypted: "<<endl;
			ShowData(bTemp, ulTemp);
			
			cout<<"Decrypting initialize";
			rv = C_DecryptInit(m_hSession, &ckMechanism, m_hKey);
			CHECK_OP(rv)
				
			cout<<"C_Decrypt[get buffer's size]";
			rv = C_Decrypt(m_hSession, bTemp, ulTemp, NULL, &ulOut);			
			CHECK_OP(rv)
				
			cout<<"Decrypt the message";
			rv = C_Decrypt(m_hSession, bTemp, ulTemp, bOut, &ulOut);
			CHECK_OP(rv)
			cout<<"Data decrypted: "<<endl;
			ShowData(bOut, ulOut);
			
			cout<<"Compare the original message and decrypted data: ";
			if(0 == memcmp(bIn, bOut, ulOut))
			{
				CHECK_OP(CKR_OK)
			}
			else
			{
				cout<<"....[FAILED]\n"<<endl;
				return CKR_GENERAL_ERROR;
			}
		}
	}
	return CKR_OK;
}

CK_RV Ssf33Test::crypt_Update()
{
	CK_RV rv = CKR_OK;
	const CK_ULONG DATA_LENGTH = 1024*3;
	CK_BYTE bIn[DATA_LENGTH] = {0}, bTemp[DATA_LENGTH] = {0}, bOut[DATA_LENGTH] = {0};
	CK_ULONG ulIn = 0, ulOut = 0, ulTemp = 0;
	CK_ULONG Mechanism[3] = {CKM_SSF33_CBC, CKM_SSF33_ECB, CKM_SSF33_CBC_PAD};
	CK_BYTE_PTR bHint[3] = {(CK_BYTE_PTR)"CKM_SSF33_CBC: ",\
							(CK_BYTE_PTR)"CKM_SSF33_ECB: ",\
							(CK_BYTE_PTR)"CKM_SSF33_CBC_PAD: "};
	for(int i=0;i<3;i++)
	{
		for (i != 2 ? ulIn = SSF33_BLOCK_LEN : ulIn = 0; ulIn < 32; i != 2 ? ulIn += SSF33_BLOCK_LEN : ++ulIn)
		{			
			for(register CK_ULONG i0 = 0;i0<ulIn;i0++)
				bIn[i0] = (CK_BYTE)i0;
			
			cout<<"\nSSF33: C_EncryptUpdate/C_DecryptUpdate: \n";
			cout<<bHint[i]<<endl;
			CK_BYTE iv[16] = {'*','2','1','0','4','z','y','b','*','2','1','0','4','z','y','b'};
			CK_MECHANISM ckMechanism = {Mechanism[i], iv, sizeof(iv)};
			cout<<"Encrypting initialize";
			rv = C_EncryptInit(m_hSession, &ckMechanism, m_hKey); 
			CHECK_OP(rv)
				
			CK_ULONG ulEncrypted = 0;
			cout<<"Encrypt the message."<<endl;
			DWORD dwLoop = ulIn / BLOCK_SIZE;
			DWORD dwLeft = ulIn % BLOCK_SIZE;
			DWORD iii = 0;
			CK_BYTE_PTR pRetData = bTemp;
			for(iii = 0; iii < dwLoop; ++iii)
			{
				cout<<"C_Encrypt[inside loop]";
				rv = C_EncryptUpdate(m_hSession, bIn + BLOCK_SIZE * iii, BLOCK_SIZE, NULL, &ulTemp);
				rv = C_EncryptUpdate(m_hSession, bIn + BLOCK_SIZE * iii, BLOCK_SIZE, pRetData, &ulTemp);
				pRetData += ulTemp;
				ulEncrypted+=ulTemp;
				CHECK_OP(rv)
			}
			if(0 != dwLeft)
			{
				cout<<"C_Encrypt[last loop]";
				rv = C_EncryptUpdate(m_hSession, bIn + BLOCK_SIZE * iii, dwLeft, NULL, &ulTemp);//get buffer's size.
				rv = C_EncryptUpdate(m_hSession, bIn + BLOCK_SIZE * iii, dwLeft, pRetData, &ulTemp);
				pRetData += ulTemp;
				ulEncrypted+=ulTemp;
				CHECK_OP(rv)
			}
			
			cout<<"C_EncryptFinal";
			rv = C_EncryptFinal(m_hSession, NULL, &ulTemp);
			rv = C_EncryptFinal(m_hSession, pRetData, &ulTemp);
			CHECK_OP(rv)
			ulEncrypted+=ulTemp;
			ulTemp = 0;
			cout<<"Data encrypted: "<<endl;
			ShowData(bTemp, ulEncrypted);
			
			cout<<"Decrypting initialize";
			CK_BYTE iv1[16] = {'*','2','1','0','4','z','y','b','*','2','1','0','4','z','y','b'};	
			CK_MECHANISM ckMechanism1 = {Mechanism[i], iv1, sizeof(iv1)};
			rv = C_DecryptInit(m_hSession, &ckMechanism1, m_hKey);
			CHECK_OP(rv)
				
			cout<<"Decrypt the message."<<endl;
			dwLoop = ulEncrypted / DEC_BLOCK_SIZE;
			iii = 0;
			pRetData = bOut;
			CK_ULONG ulDecrypt = 0;
			for(iii = 0; iii < dwLoop; ++iii)
			{
				cout<<"C_Decrypt[inside loop]";
				rv = C_DecryptUpdate(m_hSession, bTemp + DEC_BLOCK_SIZE * iii, DEC_BLOCK_SIZE, NULL, &ulTemp);//get buffer's size.
				rv = C_DecryptUpdate(m_hSession, bTemp + DEC_BLOCK_SIZE * iii, DEC_BLOCK_SIZE, pRetData, &ulTemp);
				pRetData += ulTemp;
				ulDecrypt+=ulTemp;
				CHECK_OP(rv)
			}
			cout<<"C_DecryptFinal";
			rv = C_DecryptFinal(m_hSession, NULL, &ulTemp);
			rv = C_DecryptFinal(m_hSession, pRetData, &ulTemp);
			CHECK_OP(rv)
			ulDecrypt += ulTemp;			
			cout<<"Data decrypted: "<<endl;
			ShowData(bOut, ulDecrypt);
			
			cout<<"Compare the original message and decrypted data: "<<endl;
			if(0 == memcmp(bIn, bOut, ulDecrypt))
			{
				CHECK_OP(CKR_OK)
			}
			else
			{
				cout<<"....[FAILED]"<<endl;
				return CKR_GENERAL_ERROR;
			}
		}
	}
	return CKR_OK;
}