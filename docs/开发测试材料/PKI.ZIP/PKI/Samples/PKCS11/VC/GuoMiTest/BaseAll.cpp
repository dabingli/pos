#include "BaseAll.h"

CBaseAll::CBaseAll() :
	pSlotList(NULL_PTR)
{
	;
}

CBaseAll::~CBaseAll()
{
	if(NULL_PTR != pSlotList)
	{
		delete[] pSlotList;
		pSlotList = NULL_PTR;
	}
	CK_RV rv = CKR_OK;
	if(m_hSession)
	{
		rv = C_CloseSession(m_hSession);
	}
	if(CKR_OK != rv)
	{
		cout << "....C_CloseSession failed! Return Error Code=0x" << hex << rv << endl;
	}
	rv = C_Finalize(0);
	if(CKR_OK != rv)
	{
		cout << "....C_Finalize failed! Return Error Code=0x" << hex << rv << endl;
	}
}

CK_RV CBaseAll::BaseAllStart()
{
	CK_RV rv = C_Initialize(NULL_PTR);
	if(CKR_OK != rv)
	{
		cout << "....C_Initialize failed! Return Error Code=0x" << hex << rv << endl;
		return rv;
	}
	cout << "Get the slots information..." << endl;
	CK_ULONG ulCount = 0;
	rv = C_GetSlotList(TRUE, NULL_PTR, &ulCount);
	if(CKR_OK != rv)
	{
		cout << "....C_GetSlotList failed! Return Error Code=0x" << hex << rv << endl;
		return rv;
	}
	if(ulCount <= 0)
	{
		cout << "....No slot with token attached." << endl;
		return CKR_TOKEN_NOT_PRESENT;
	}
	cout << "Allocate memory for slots..." << endl;
	pSlotList = (CK_SLOT_ID_PTR)new CK_SLOT_ID[ulCount];
	if(!pSlotList)
	{
		cout << "....No slots!" << endl;
		return CKR_HOST_MEMORY;
	}
	else
	{
		cout << "Get " << ulCount << " slot attached to USB port!" << endl;
	}
	cout << "Get the slots information." << endl;
	rv = C_GetSlotList(TRUE, pSlotList, &ulCount);
	if(CKR_OK != rv)
	{
		cout << "....C_GetSLotList failed! Return Error Code=0x" << hex << rv << endl;
		return rv;
	}
	unsigned char ucPin[32] = {0};
	cout << "Open a session to communicate with the UsbToken..." << endl;
	rv = C_OpenSession(pSlotList[0],
		CKF_RW_SESSION | CKF_SERIAL_SESSION,
		NULL_PTR, NULL_PTR, &m_hSession);
	if(CKR_OK != rv)
	{
		cout << "....C_OpenSession failed! Return Error Code=0x" << hex << rv << endl;
		return rv;
	}
	
	CK_TOKEN_INFO tokenInfo = {0};
	rv = C_GetTokenInfo(pSlotList[0], &tokenInfo);
	if (CKR_OK != rv)
	{
		cout << "....Can not get token info! Return Error Code=0x" <<hex << rv << endl;
		return rv;
	}	
	cout << "Input user-pin to login first:" << endl;
	cin >> ucPin;
	rv = C_Login(m_hSession, CKU_USER, ucPin,
		strlen((char *) ucPin)); 
	
	if(rv != CKR_OK)
	{
		cout << "....C_Login failed! Return Error Code=0x" << hex << rv << endl;
		return rv;
	} 
	cout << "...C_Login OK!" << endl; 
	return rv;
}

void CBaseAll::ShowData(unsigned char *pData, unsigned long ulDataLen)
{
	cout <<"Length of data to be showed is: "<< dec<<ulDataLen<<endl;
	if(pData == NULL)
	{
		cout << "...Data to be showed is NULL!" <<endl;
		return ;
	}
	else
	{
		for(register unsigned long i=0;i<ulDataLen;i++)
		{
			if(i%16==0)
			{
				cout << endl;
			}
			cout << cout.width(3) << hex << (int)pData[i] << " ";
		}
		cout << endl;
	}
}