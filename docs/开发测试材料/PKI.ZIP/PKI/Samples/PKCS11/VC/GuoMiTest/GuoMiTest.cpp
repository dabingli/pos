// GuoMiTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SSF33Test.h"
#include "SCB2Test.h"

int main(int argc, char* argv[])
{
	cout<<"[]==================================================[]"<<endl;
	cout<<" |             GuoMi PKCS#11 Demo               |"<<endl;				
	cout<<"[]==================================================[]"<<endl;
	
	char* strTestItem = NULL;
	int iTestItem = 0xFF;
	for(;;)
	{
		if(argv[1] == NULL)
		{
			cout<<"1: SSF33  2: SCB2  0: Exit."<<endl;
			char szTest[32] = {0};
			cout<< "Please select a testing item: ";
			cin >> szTest;
			iTestItem = atoi(szTest);
		}
		else
		{
			char *temp = NULL;
			temp = _strupr( _strdup(argv[1]));
			cout << temp<<endl;
			if(0 == strcmp(temp, "-SSF33"))
				iTestItem = 1;
			else if(0 == strcmp(temp, "-SCB2"))
				iTestItem = 2;		
			else 
				iTestItem = 0;
		}
		switch(iTestItem)
		{
		case 1:
			{
				Ssf33Test test;
				test.Test();
			}
			break;
		case 2:
			{
				Scb2Test test;	
				test.Test();
			}
			break;
		case 0:
			{
				cout<<"\n\n Exit!"<<endl;
			}
			return 0;
		default:
			break;
		}
	}
	return 0;
}