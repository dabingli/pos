/*
[]=========================================================================[]

	Copyright(C) Feitian Technologies Co., Ltd.
	All rights reserved.
  
FILE:
	BaseAll.h

DESC:
[]=========================================================================[]
*/
#ifndef _BASSALL_H_
#define  _BASSALL_H_

#include "StdAfx.h"

class CBaseAll
{
public:
	CBaseAll();
	virtual ~CBaseAll();
	
	CK_RV BaseAllStart();
	void ShowData(unsigned char *pData, unsigned long ulDataLen);
	
protected:
	CK_SESSION_HANDLE m_hSession;
	
private:
	CK_SLOT_ID_PTR pSlotList;	
	unsigned char m_ucPin[32];
};

#define CHECK_OP(rvRet)														\
{																			\
	if(CKR_OK == (rvRet))													\
	{																		\
		cout<<"....[OK]."<<endl;											\
	}																		\
	else																	\
	{																		\
		cout<<"....[FAILED] Return Error Code = 0x" << hex << rvRet <<endl;	\
		cout<<"*******************************************\n"<<endl;		\
		return (rvRet);														\
	}																		\
}

#endif 