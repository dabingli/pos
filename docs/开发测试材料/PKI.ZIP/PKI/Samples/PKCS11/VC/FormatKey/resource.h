//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FormatKey.rc
//
#define IDD_LOW_INIT_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_TOKEN                       130
#define IDC_EDIT_TOKEN_NAME             1000
#define IDC_EDIT_SOPIN                  1001
#define IDC_EDIT_USERPIN                1002
#define IDC_EDIT_SOPIN_EC               1003
#define IDC_EDIT_USERPIN_EC             1004
#define IDC_EDIT_PUBSIZE                1005
#define IDC_EDIT_PRVSIZE                1006
#define IDC_EDIT_OEMID                  1007
#define IDC_EDIT_RSA_COUNT              1008
#define IDC_MSG_RESULT                  1009
#define IDC_MSG_TOTALRESULT             1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
