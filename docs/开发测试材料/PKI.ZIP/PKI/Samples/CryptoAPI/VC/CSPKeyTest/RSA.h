
#if !defined(AFX_RSA_H__4241BB26_7B52_44A8_8CAB_FE52649A0733__INCLUDED_)
#define AFX_RSA_H__4241BB26_7B52_44A8_8CAB_FE52649A0733__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRSA  
{
public:
	CRSA();
	virtual ~CRSA();

	void TestRSA(void);
};

#endif // !defined(AFX_RSA_H__4241BB26_7B52_44A8_8CAB_FE52649A0733__INCLUDED_)
