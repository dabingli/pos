//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DERIVEKEYTEST_H__CC86447A_01DA_4D4C_BD3C_29DA20C9F7A3__INCLUDED_)
#define AFX_DERIVEKEYTEST_H__CC86447A_01DA_4D4C_BD3C_29DA20C9F7A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DeriveKeyTest  
{
public:
	DeriveKeyTest();
	virtual ~DeriveKeyTest();

	void Testkey(DWORD ulALG);
};

#endif // !defined(AFX_DERIVEKEYTEST_H__CC86447A_01DA_4D4C_BD3C_29DA20C9F7A3__INCLUDED_)
