// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__A978BF46_53F1_4029_BEF9_2BC606091375__INCLUDED_)
#define AFX_STDAFX_H__A978BF46_53F1_4029_BEF9_2BC606091375__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>	// For std::setfill(), std::setw()...
using namespace std;

#include <windows.h>
#include <wincrypt.h>
#include <csp/csp_ext.h>
#include <stdio.h>

#include "generic.h"

#endif // !defined(AFX_STDAFX_H__A978BF46_53F1_4029_BEF9_2BC606091375__INCLUDED_)
