import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.codec.digest.DigestUtils;

public class DigestTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
        String fileName = "d:/tmp/ID100022201605310001.req";

        FileInputStream fis = null;
        byte[] fileContent = null;

        try {
            fis = new FileInputStream(new File(fileName));
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        }

        try {
            fileContent = readAllFromStream(fis);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        if (null != fis) {
            try {
                fis.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
            fis = null;
        }

        String digestSHA1 = DigestUtils.shaHex(fileContent);
        System.out.println("SHA1:" + digestSHA1);

    }

    public static byte[] readAllFromStream(InputStream is) throws IOException {
        int total = 0;
        byte[] buf = null;

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        byte[] tmp = new byte[8 * 1024];

        try {

            int readBytes = is.read(tmp);
            while (readBytes != -1) {
                bos.write(tmp, 0, readBytes);
                total = total + readBytes;
                readBytes = is.read(tmp);
            }

            buf = bos.toByteArray();

            bos.close();

            bos = null;

            tmp = null;
        } finally {
            if (null != bos) {
                try {
                    bos.close();
                } catch (Throwable t) {
                    // nothing can do here
                }
                bos = null;
            }

            tmp = null;
        }

        return buf;
    }

}
