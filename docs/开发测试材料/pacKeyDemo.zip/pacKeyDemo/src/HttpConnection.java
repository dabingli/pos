import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.cbhb.payment.pac.core.OfflineResolver;
import com.cbhb.payment.pac.core.PacKeyManager;

public class HttpConnection {
    static String CHARSET = "utf-8";
    static String hostUrl = "http://221.239.93.138:9081/pacServer/connect.do";
    private static PacKeyManager keyManager = null;

    static {
        org.apache.xml.security.Init.init();
        keyManager = new PacKeyManager();
        keyManager.setKeyAlias("key4pac");
        keyManager.setKeyPassword("111111");
        keyManager.setKeystoreFile("d:/pacClient/cbhbpac.jks");
        keyManager.setKeystorePassword("111111");
        keyManager.setKeystoreType("JKS");
    }

    public static void main(String[] args) throws Exception {
        String sign_value = "<?xml version='1.0' encoding='utf-8'?><Cbhbpac><Message id=\"fb8ba30587f940c3b15e316dcd1f6ce6\"><SCTQReq id=\"SCTQReq\"><version>1.0.0</version><instId>100022</instId><certId>1000222016030701</certId><serialNo>4e6dc3e73acb41e19486868c9b954d9c</serialNo><date>20150311 16:12:52</date></SCTQReq></Message></Cbhbpac>";
        System.out.println("xml:" + sign_value);
        //begin sign
        sign_value = sign(sign_value, "SCTQ");
        System.out.println("sign:" + sign_value);
        String retMsg = issuePac(sign_value);
        System.out.println("recv:" + retMsg);

        System.out.println("recv original:" + retMsg);
        System.out.println(verify(retMsg));//verify

        retMsg = retMsg.replaceAll("\r\n", "");
        retMsg = retMsg.replaceAll("\n", "");
        retMsg = retMsg.replaceAll("  ", "");
        System.out.println("recv processed:" + retMsg);
    }

    public static String issuePac(String sndContent) throws Exception {
        final String contentType = "application/xml;charset=utf-8";
        byte[] content = null;
        try {
            content = sndContent.getBytes(CHARSET);
        } catch (UnsupportedEncodingException e) {
            // log.error("Error occur !", e);
        }

        System.getProperties().put("java.protocol.handler.pkgs",
                "com.ibm.net.ssl.www2.protocol");

        URL myUrl = new URL(hostUrl);
        HttpURLConnection httpConn = (HttpURLConnection) myUrl.openConnection();
        httpConn.setRequestMethod("POST");

        if (httpConn instanceof HttpsURLConnection) {
            // HttpsURLConnection httpsConn = (HttpsURLConnection) httpConn;
            // httpsConn.setHostnameVerifier(hv);
            // X509TrustManager xtm = new PacTrustManager();
            // TrustManager mytm[] = { xtm };
            // SSLContext ctx = SSLContext.getInstance("SSL");
            // ctx.init(null, mytm, new SecureRandom());
            // SSLSocketFactory factory = ctx.getSocketFactory();
            // httpsConn.setSSLSocketFactory(factory);
        }

        httpConn.addRequestProperty("Content-Type", contentType);
        httpConn.setDoInput(true);
        httpConn.setDoOutput(true);
        httpConn.connect();
        OutputStream out = httpConn.getOutputStream();
        out.write(content);
        out.flush();
        out.close();
        String rspContent = null;
        byte[] rspByte = readAllByteFromStream(httpConn.getInputStream());
        if (null != rspByte) {
            rspContent = new String(rspByte, CHARSET);
        } else {
            System.out.println("can not read any content from server!");
        }
        httpConn.disconnect();
        httpConn = null;
        myUrl = null;
        return rspContent;
    }

    //******sign
    private static String sign(String xmlContent, String transType)
            throws Exception {
        String xmlSign = null;
        System.out.println("begin sign---:" + xmlContent);
        try {

            Document doc = string2Doc(xmlContent, CHARSET);

            XMLSignature sign = new XMLSignature(doc, "",
                    XMLSignature.ALGO_ID_SIGNATURE_RSA);

            sign.getSignedInfo().addResourceResolver(new OfflineResolver());

            Node messageNode = doc.getElementsByTagName("Message").item(0);
            messageNode.appendChild(sign.getElement());

            Transforms transforms = new Transforms(doc);
            transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);

            sign.addDocument("#" + transType + "Req", transforms,
                    org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);

            //sign***********************************
            System.out.println("getPrivateKey():");
            sign.sign(keyManager.getPrivateKey());

            System.out.println("doc---:" + doc);

            xmlSign = doc2String(doc, CHARSET);

            System.out.println("sign xml:" + xmlSign);

        } catch (Exception e) {
           e.printStackTrace();
        }
        System.out.println("finish sign---:" + xmlSign);
        return xmlSign;

    }

    private static byte[] readAllByteFromStream(InputStream is)
            throws Exception {
        byte[] buf = new byte[8072];
        ByteArrayOutputStream baos = new ByteArrayOutputStream(8072);
        int readCount = is.read(buf);
        while (readCount != -1) {
            baos.write(buf, 0, readCount);
            readCount = is.read(buf);
        }
        byte[] rsByte = baos.toByteArray();
        baos.close();
        baos = null;
        return rsByte;
    }


    private static String doc2String(Document doc, String charset)
            throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        if (null != charset) {
            t.setOutputProperty("encoding", charset);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        t.transform(new DOMSource(doc), new StreamResult(bos));
        String xmlStr = null;
        if (null != charset) {
            xmlStr = bos.toString(charset);
        } else {
            xmlStr = bos.toString();
        }
        return xmlStr;
    }

    private static Document string2Doc(String xml, String charset)
            throws Exception {
        InputStream is = IOUtils.toInputStream(xml, charset);
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
                .newInstance();
        docBuilderFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document doc = null;
        if (null != charset) {
            doc = docBuilder.parse(is, charset);
        } else {
            doc = docBuilder.parse(is);
        }
        return doc;
    }

    private static boolean verify(String xml) {
        boolean flag = false;
        try {
            Document doc = string2Doc(xml, "UTF-8");
            Element nscontext = XMLUtils.createDSctx(doc, "ds",
                    org.apache.xml.security.utils.Constants.SignatureSpecNS);
            Element signElement = (Element) XPathAPI.selectSingleNode(doc,
                    "//ds:Signature[1]", nscontext);
            if (null != signElement) {
                org.apache.xml.security.signature.XMLSignature signature = new org.apache.xml.security.signature.XMLSignature(
                        signElement, "");
                String path = "cbhbpac.cer";
                CertificateFactory certificateFactory = CertificateFactory
                        .getInstance("X.509");
                FileInputStream in = new FileInputStream(path);
                Certificate certificate = certificateFactory
                        .generateCertificate(in);
                System.out.println("Cert:" + certificate);
                PublicKey key = certificate.getPublicKey();
                System.out.println(key);
                flag = signature.checkSignatureValue(key);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
