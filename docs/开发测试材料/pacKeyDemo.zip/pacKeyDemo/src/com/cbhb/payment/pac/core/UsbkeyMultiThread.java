package com.cbhb.payment.pac.core;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;


public class UsbkeyMultiThread extends Thread {
	public static String CHARSET = "utf-8";

	protected static Log log = LogFactory.getLog(UsbkeyMultiThread.class);

	public UsbkeyMultiThread(PacUsbkeyManager aPacUsbkeyManager, Map dtMap) {
		super();
		this.pacUsbkeyManager = aPacUsbkeyManager;
		this.dataMap = dtMap;
	}

	private PacUsbkeyManager pacUsbkeyManager = null;

	private Map dataMap = null;

	public static void main(String[] args) {
		testVerify();
	}

	public static void testSign() {
		String usbkeyPwd="88888888";
		String usbkeyCfgFile = "d:/BHIBS/keystore/FeiTian.cfg";
		
		PacUsbkeyManager pacUsbkeyManager = new PacUsbkeyManager(usbkeyPwd, usbkeyCfgFile);
		pacUsbkeyManager.load();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

		DecimalFormat df = new DecimalFormat("000000");
		String batchNo = sdf.format(new Date(System.currentTimeMillis()));

		String instSeq = null;
		String instId = "100099";
		String certId = "1000992014081101";
		String pyrAct = "2000713325000168";
		String pyrNam = "2000713325";
		String pyeAct = "1100000000316889";
		String pyeNam = "����";
		String pyeBnk = "402731057238";
		String postscript = "����TEST";

		int iCount = 1000;

		for (int i = 0; i < iCount; i++) {
			try {
				Map dataMap = new HashMap();

				dataMap.put("transType", "SCHP");

				dataMap.put("instId", instId);
				dataMap.put("certId", certId);
				dataMap.put("pyrAct", pyrAct);
				dataMap.put("pyrNam", pyrNam);
				dataMap.put("pyeAct", pyeAct);
				dataMap.put("pyeNam", pyeNam);
				dataMap.put("pyeBnk", pyeBnk);
				dataMap.put("postscript", postscript);

				Random rnd = new Random(System.currentTimeMillis());
				String amt = String.valueOf(rnd.nextInt(9) + 1);
				instSeq = batchNo + df.format(i);
				dataMap.put("instSeq", instSeq);
				dataMap.put("amt", amt);

				new UsbkeyMultiThread(pacUsbkeyManager, dataMap).start();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void testVerify() {
		org.apache.xml.security.Init.init();

		File certFile = new File("d:/BHIBS/keystore/usbkey.cer");
		FileInputStream fis = null;

		PublicKey pkey = null;

		try {
			fis = new FileInputStream(certFile);
			CertificateFactory certificateFactory = CertificateFactory
                    .getInstance("X.509");
            Certificate cert = certificateFactory
                    .generateCertificate(fis);
			
			
			log.info("Cert:"+cert);
			pkey = cert.getPublicKey();
			log.info("Public Key:"+pkey);
			fis.close();
			fis = null;
		} catch (Exception e) {
			log.error("Error occur!", e);
		}

		File dir = new File("d:/BHIBS/sign");

		File[] sigFiles = dir.listFiles();
		File sigFile = null;

		if (null != sigFiles) {
			int fileCount = sigFiles.length;

			log.info("File to verify:" + fileCount);

			byte[] fileCont = null;
			String xml = null;
			boolean verifyFlag = false;

			for (int i = 0; i < fileCount; i++) {
				sigFile = sigFiles[i];
				try {
					fis = new FileInputStream(sigFile);
					fileCont = PacUtil.readAllByteFromStream(fis);
					xml = new String(fileCont, CHARSET);
					verifyFlag = verify(xml, pkey);

					if (!verifyFlag) {
						log.info("Verify failed :" + xml);
					}
					xml = null;
					fileCont = null;
				} catch (Exception e) {
					log.error("Error occur!", e);
				}

			}
		}

		sigFile = null;
		sigFiles = null;
		dir = null;

	}

	public void run() {
		long curTime = System.currentTimeMillis();
		log.info("Begin run " + this.getId());

		try {
			String instSeq = (String) dataMap.get("instSeq");

			String transType = (String) dataMap.get("transType");

			String sndMsg = PacUtil.formatData(dataMap, CHARSET);

			String sndMsgSigned = sign(sndMsg, transType,
					pacUsbkeyManager.getClientKey());

			File sigFile = new File("d:/BHIBS/sign", instSeq + ".sig");

			FileOutputStream fos = new FileOutputStream(sigFile);
			fos.write(sndMsgSigned.getBytes(CHARSET));
			fos.flush();
			fos.close();
			fos = null;

		} catch (Exception e) {
			log.error("Error occur !", e);
		}

		log.info("Finish run " + this.getId() + ", timing :"
				+ (System.currentTimeMillis() - curTime));
	}

	// ******sign
	private String sign(String xmlContent, String transType, PrivateKey privKey) {
		String xmlSign = null;
		try {

			Document doc = string2Doc(xmlContent, CHARSET);

			XMLSignature sign = new XMLSignature(doc, "",
					XMLSignature.ALGO_ID_SIGNATURE_RSA);

			sign.getSignedInfo().addResourceResolver(new OfflineResolver());

			Node messageNode = doc.getElementsByTagName("Message").item(0);
			messageNode.appendChild(sign.getElement());

			Transforms transforms = new Transforms(doc);
			transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);

			sign.addDocument("#" + transType + "Req", transforms,
					org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);

			// sign***********************************
			long lb = System.currentTimeMillis();
			sign.sign(privKey);
			long le = System.currentTimeMillis();

			log.info("Sign time :" + (le - lb));

			xmlSign = doc2String(doc, CHARSET);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return xmlSign;

	}

	/**
	 * @param xml
	 * @return
	 * @throws Exception
	 */
	private static Document string2Doc(String xml, String charset)
			throws Exception {

		InputStream is = IOUtils.toInputStream(xml, charset);

		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
				.newInstance();
		docBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

		Document doc = null;
		if (null != charset) {
			doc = docBuilder.parse(is, charset);
		} else {
			doc = docBuilder.parse(is);
		}
		return doc;
	}

	/**
	 * @param doc
	 * @return
	 * @throws Exception
	 */
	private static String doc2String(Document doc, String charset)
			throws Exception {

		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();
		if (null != charset) {
			t.setOutputProperty("encoding", charset);
		}

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		t.transform(new DOMSource(doc), new StreamResult(bos));
		String xmlStr = null;

		if (null != charset) {
			xmlStr = bos.toString(charset);
		} else {
			xmlStr = bos.toString();
		}
		return xmlStr;
	}

	private static boolean verify(String xml, PublicKey pubKey) {
		boolean flag = false;
		try {
			Document doc = string2Doc(xml, "UTF-8");
			Element nscontext = XMLUtils.createDSctx(doc, "ds",
					org.apache.xml.security.utils.Constants.SignatureSpecNS);
			Element signElement = (Element) XPathAPI.selectSingleNode(doc,
					"//ds:Signature[1]", nscontext);
			if (null != signElement) {
				org.apache.xml.security.signature.XMLSignature signature = new org.apache.xml.security.signature.XMLSignature(
						signElement, "");

				System.out.println(pubKey);
				flag = signature.checkSignatureValue(pubKey);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
