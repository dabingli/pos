/*
 *
 */
package com.cbhb.payment.pac.core;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cbhb.payment.common.Constants;

/**
 *  
 */
public class LocalPacFileProxy {

	protected static Log log = LogFactory.getLog(LocalPacFileProxy.class);

	private int port = -1;

	private int timeout = -1;

	private boolean running = false;

	private ServerSocket serverSocket = null;

	private PacFileClientPool pacFileClientPool = null;

	/**
     *  
     */
	public LocalPacFileProxy() {
		super();
	}

	public void start() {
		Socket clientSocket = null;

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacFileProxy start begin!");
		}

		try {
			serverSocket = new ServerSocket(port);
			running = true;

			while (running) {
				try {
					clientSocket = serverSocket.accept();
					if (null != clientSocket) {
						if (timeout != -1) {
							clientSocket.setSoTimeout(timeout);
						}

						pacFileClientPool.process(clientSocket);

					}
				} catch (Exception anyE) {
					anyE.printStackTrace(System.err);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacFileProxy start end!");
		}
	}

	public void stop() {
		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacFileProxy stop begin!");
		}

		running = false;

		if (null != serverSocket) {
			try {
				serverSocket.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			serverSocket = null;
		}

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacFileProxy stop end!");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		stop();

		super.finalize();
	}

	/**
	 * @return Returns the port.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @param port
	 *            The port to set.
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @return Returns the timeout.
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout
	 *            The timeout to set.
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * @return Returns the running.
	 */
	public boolean isRunning() {
		return running;
	}

	public PacFileClientPool getPacFileClientPool() {
		return pacFileClientPool;
	}

	public void setPacFileClientPool(PacFileClientPool pacFileClientPool) {
		this.pacFileClientPool = pacFileClientPool;
	}

}