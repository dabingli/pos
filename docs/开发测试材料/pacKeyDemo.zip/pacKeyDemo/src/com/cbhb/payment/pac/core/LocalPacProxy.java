/*
 *
 */
package com.cbhb.payment.pac.core;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cbhb.payment.common.Constants;

/**
 *  
 */
public class LocalPacProxy {

	protected static Log log = LogFactory.getLog(LocalPacProxy.class);

	private int port = -1;

	private int timeout = -1;

	private boolean running = false;

	private ServerSocket serverSocket = null;

	private PacClientPool pacClientPool = null;

	/**
     *  
     */
	public LocalPacProxy() {
		super();
		org.apache.xml.security.Init.init();
	}

	public void start() {
		Socket clientSocket = null;

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacProxy start begin!");
		}

		try {
			serverSocket = new ServerSocket(port);
			running = true;

			while (running) {
				try {
					clientSocket = serverSocket.accept();
					if (null != clientSocket) {
						if (timeout != -1) {
							clientSocket.setSoTimeout(timeout);
						}

						pacClientPool.process(clientSocket);

					}
				} catch (Exception anyE) {
					anyE.printStackTrace(System.err);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacProxy start end!");
		}
	}

	public void stop() {
		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacProxy stop begin!");
		}

		running = false;

		if (null != serverSocket) {
			try {
				serverSocket.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			serverSocket = null;
		}

		if (log.isDebugEnabled()) {
			log.debug(Constants.LOG_PREFIX + "LocalPacProxy stop end!");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() throws Throwable {
		stop();

		super.finalize();
	}

	/**
	 * @return Returns the port.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * @param port
	 *            The port to set.
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @return Returns the timeout.
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * @param timeout
	 *            The timeout to set.
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	/**
	 * @return Returns the running.
	 */
	public boolean isRunning() {
		return running;
	}

	public static void main(String[] args) {

		String transType = "SCSP";// SCSP or BIQ or SCTQ

		Map dataMap = new HashMap();
		Map rspMap = null;
		dataMap.put("transType", transType);

		dataMap.put("instId", "100099");
		dataMap.put("certId", "1000992014081101");
		dataMap.put("pyrAct", "2000713325000168");
		dataMap.put("pyrNam", "2000713325");
		dataMap.put("instSeq", "" + System.currentTimeMillis());
		dataMap.put("pyeAct", "330201100120");
		dataMap.put("pyeNam", "�����˻�");
		dataMap.put("pyeBnk", "402731057238");
		dataMap.put("amt", "1.01");
		dataMap.put("postscript", "TEST��;");

		Socket socket = null;
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		try {
			socket = new Socket("127.0.0.1", 18601);
			socket.setSoTimeout(300000);

			oos = new ObjectOutputStream(socket.getOutputStream());

			oos.writeObject(dataMap);
			oos.flush();
			socket.shutdownOutput();

			ois = new ObjectInputStream(socket.getInputStream());
			rspMap = (Map) ois.readObject();

			oos.close();
			oos = null;

			ois.close();
			ois = null;

			socket.close();
			socket = null;

		} catch (UnknownHostException e) {
			log.error("Error occur !", e);
		} catch (IOException e) {
			log.error("Error occur !", e);
		} catch (ClassNotFoundException e) {
			log.error("Error occur !", e);
		}

		if (null != oos) {
			try {
				oos.close();
			} catch (IOException e) {
				log.error("Error occur !", e);
			}
			oos = null;
		}

		if (null != ois) {
			try {
				ois.close();
			} catch (IOException e) {
				log.error("Error occur !", e);
			}
			ois = null;
		}

		if (null != socket) {
			try {
				socket.close();
			} catch (IOException e) {
				log.error("Error occur !", e);
			}
			socket = null;
		}

		log.info("RspMap:" + rspMap);

		if (null == rspMap) {
			log.error("ͨѶ��ʱ�����Ժ����ԣ�");
		}

	}

	public PacClientPool getPacClientPool() {
		return pacClientPool;
	}

	public void setPacClientPool(PacClientPool pacClientPool) {
		this.pacClientPool = pacClientPool;
	}

}