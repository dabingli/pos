package com.cbhb.payment.pac.core;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Enumeration;

import sun.security.pkcs11.SunPKCS11;

public class PacUsbkeyManager {
	public PacUsbkeyManager(String password, String cfgFileName) {
		super();
		this.passwd = password;
		this.cfgFile = cfgFileName;
	}

	private String cfgFile = "d:/BHIBS/keystore/FeiTian.cfg";

	private String passwd = "88888888";

	private PrivateKey clientKey = null;

	public String getCfgFile() {
		return cfgFile;
	}

	public void setCfgFile(String cfgFile) {
		this.cfgFile = cfgFile;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public void load() {
		try {

			Provider p = new SunPKCS11(cfgFile);
			Security.addProvider(p);

			char[] pin = passwd.toCharArray();

			KeyStore ks = KeyStore.getInstance("PKCS11", p);
			ks.load(null, pin);

			Enumeration aliases = ks.aliases();

			String alias = null;

			alias = (String) aliases.nextElement();

			clientKey = (PrivateKey) ks.getKey(alias, pin);

		} catch (KeyStoreException kse) {
			kse.printStackTrace();
		} catch (NoSuchAlgorithmException nsae) {
			nsae.printStackTrace();
		} catch (UnrecoverableKeyException uke) {
			uke.printStackTrace();
		} catch (CertificateException ce) {
			ce.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

	}

	public PrivateKey getClientKey() {
		return clientKey;
	}

}
