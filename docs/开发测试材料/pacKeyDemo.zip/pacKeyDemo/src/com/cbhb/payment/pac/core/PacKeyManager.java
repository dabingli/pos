package com.cbhb.payment.pac.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.util.Enumeration;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class PacKeyManager {
	protected static Log log = LogFactory.getLog(PacKeyManager.class);

	private String keystoreType = null;
	private String keystoreFile = null;
	private String keystorePassword = null;
	private String keyAlias = null;
	private String keyPassword = null;
	private String serverCertAlias = null;

	private KeyStore keyStore = null;

	public PacKeyManager() {
		super();
	}

	public KeyStore getKeyStore() {
		if (null == keyStore) {
			this.loadKeyStore();
		}
		return keyStore;
	}

	public String getKeystoreType() {
		return keystoreType;
	}

	public void setKeystoreType(String keystoreType) {
		this.keystoreType = keystoreType;
	}

	public String getKeystoreFile() {
		return keystoreFile;
	}

	public void setKeystoreFile(String keystoreFile) {
		this.keystoreFile = keystoreFile;
	}

	public String getKeystorePassword() {
		return keystorePassword;
	}

	public void setKeystorePassword(String keystorePassword) {
		this.keystorePassword = keystorePassword;
	}

	public String getKeyAlias() {
		return keyAlias;
	}

	public void setKeyAlias(String keyAlias) {
		this.keyAlias = keyAlias;
	}

	public String getKeyPassword() {
		return keyPassword;
	}

	public void setKeyPassword(String keyPassword) {
		this.keyPassword = keyPassword;
	}

	public PrivateKey getPrivateKey() {
		PrivateKey key = null;
		if (null == keyStore) {
			loadKeyStore();
		}

		try {
			key = (PrivateKey) keyStore.getKey(keyAlias,
					keyPassword.toCharArray());
		} catch (UnrecoverableKeyException e) {
			log.error("Error get private key !", e);
		} catch (KeyStoreException e) {
			log.error("Error get private key !", e);
		} catch (NoSuchAlgorithmException e) {
			log.error("Error get private key !", e);
		}

		return key;
	}

	public Certificate getCertificate() {
		Certificate cert = null;
		try {
			cert = keyStore.getCertificate(this.serverCertAlias);
		} catch (KeyStoreException e) {
			log.error("Error get certificate key !", e);
		}
		return cert;
	}

	private void loadKeyStore() {
		InputStream inputStream = null;

		Security.addProvider(new BouncyCastleProvider());

		try {
			File fileOfCa = new File(keystoreFile);
			if (fileOfCa.exists()) {
				inputStream = new FileInputStream(fileOfCa);
			}
		} catch (FileNotFoundException fnfe) {
			log.error("Error load keystore!", fnfe);
		}

		try {
			inputStream = new FileInputStream(getKeystoreFile());
		} catch (FileNotFoundException e1) {
			log.error("Error in loadKeyStore File Not Found");
		}

		if (inputStream == null) {
			log.error("Error in loadKeyStore File Not Found");
		} else {
			char[] pass = keystorePassword.toCharArray();

			try {
				keyStore = KeyStore.getInstance(keystoreType);
				keyStore.load(inputStream, pass);
			} catch (Exception e) {
				log.error("Error in PayGateSignVerify Load the Keystore ", e);
			}
		}
	}

	public String getServerCertAlias() {
		return serverCertAlias;
	}

	public void setServerCertAlias(String serverCertAlias) {
		this.serverCertAlias = serverCertAlias;
	}

	public static void main(String[] args) {
		try {
			String pfxFile = "d:/BHIBS/keystore/insttest.pfx";
			String jksFile = "d:/BHIBS/keystore/cbhbclient.jks";
			String newJksFile = "d:/BHIBS/keystore/cbhbclient.jks";

			//����jks�ļ���֤�����
			String alias = "pacclienttest";

			//����pfx�ļ�ʱ���õ�����
			String pfxPwd = "111111";
			
			//jks�ļ�����
			String jksPwd = "111111";
			
			//pfx�ļ���֤���������
			String inputKeyPwd = "111111";
			
			//����jks�ļ���֤���������
			String outputKeyPwd = "111111";

			char[] nPassword = null;

			KeyStore inputKeyStore = KeyStore.getInstance("PKCS12");
			FileInputStream fis = new FileInputStream(pfxFile);

			if (null != pfxPwd && !"".equals(pfxPwd)) {
				nPassword = pfxPwd.toCharArray();
			}
			inputKeyStore.load(fis, nPassword);

			fis.close();
			fis = null;

			KeyStore outputKeyStore = KeyStore.getInstance("JKS");

			outputKeyStore.load(new FileInputStream(jksFile),
					jksPwd.toCharArray());

			Enumeration enums = inputKeyStore.aliases();

			String keyAlias = (String) enums.nextElement();
			System.out.println("Key alias:" + keyAlias);

			Key key = inputKeyStore.getKey(keyAlias, inputKeyPwd.toCharArray());
			Certificate[] certChain = inputKeyStore
					.getCertificateChain(keyAlias);
			outputKeyStore.setKeyEntry(alias, key, outputKeyPwd.toCharArray(),
					certChain);

			FileOutputStream fos = new FileOutputStream(newJksFile);

			if (null != jksPwd && !"".equals(jksPwd)) {
				nPassword = jksPwd.toCharArray();
			}
			outputKeyStore.store(fos, nPassword);

			fos.close();
			fos = null;
		} catch (Throwable t) {
			t.printStackTrace();
		}

	}

}
