package com.cbhb.payment.pac.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Enumeration;

import sun.security.pkcs11.SunPKCS11;

import com.cbhb.data.util.CbhbFileProperties;

/**
 *  
 */
public class ClientConfig {
	private PrivateKey clientKey = null;

	private PublicKey serverKey = null;

	private KeyStore keyStore = null;

	private String storePassword = null;

	private String keyPassword = null;

	private String usbkeyPassword = null;

	private String serverUrl = null;

	private String fileServerUrl = null;

	private String keyManagerAlgorithm = "SunX509";

	private String trustManagerAlgorithm = "SunX509";

	private String proxySet = null;

	private String proxyHost = null;

	private String proxyPort = null;

	private String proxyUser = null;

	private String proxyPassword = null;

	private String cifNo = null;

	private String listenPort = null;

	private String fileListenPort = null;

	private String cbsListenPort = null;

	private String clientTimeout = null;

	private String serverTimeout = null;

	private String ipAddress = null;

	private String requestProcessor = null;

	private String requestFileProcessor = null;

	private String requestCbsProcessor = null;

	private String certAlias = null;

	private String certFile = null;

	private String usbkeyConfFile = null;

	private String usbkeyFlag = null;

	private static ClientConfig clientConfig = null;

	public static ClientConfig getInstance() {
		if (null == clientConfig) {
			clientConfig = new ClientConfig();
		}

		return clientConfig;
	}

	private ClientConfig() {
		super();

		CbhbFileProperties fp = new CbhbFileProperties(configFileName);

		// String fileName =
		// ClientConfig.class.getResource(configFileName).getFile();

		serverUrl = fp.getProperty("serverUrl");
		fileServerUrl = serverUrl;

		if (serverUrl.endsWith("/")) {
			serverUrl = serverUrl + "shchEntry.do";
			fileServerUrl = fileServerUrl + "shchFileEntry.do";
		} else {
			serverUrl = serverUrl + "/shchEntry.do";
			fileServerUrl = fileServerUrl + "/shchFileEntry.do";
		}

		proxySet = fp.getProperty("proxySet", "false");
		proxyHost = fp.getProperty("proxyHost");
		proxyPort = fp.getProperty("proxyPort");
		proxyUser = fp.getProperty("proxyUser");
		proxyPassword = fp.getProperty("proxyPassword");

		cifNo = fp.getProperty("cifNo");
		listenPort = fp.getProperty("listen_port");
		fileListenPort = fp.getProperty("file_listen_port");
		cbsListenPort = fp.getProperty("cbs_listen_port");
		ipAddress = fp.getProperty("ip_address");
		requestProcessor = fp.getProperty("request_processor");
		requestFileProcessor = fp.getProperty("request_file_processor");
		requestCbsProcessor = fp.getProperty("request_cbs_processor");
		certAlias = fp.getProperty("certAlias");
		certFile = fp.getProperty("certFile");
		clientTimeout = fp.getProperty("clientTimeout");
		serverTimeout = fp.getProperty("serverTimeout");
		usbkeyFlag = fp.getProperty("usbkeyFlag");
		usbkeyConfFile = fp.getProperty("usbkeyConfFile");

		String cafile = fp.getProperty("cafile");
		String storePwd = fp.getProperty("store_password");
		String keyPwd = fp.getProperty("key_password");
		String usbkeyPwd = fp.getProperty("usbkeyPassword");
		// String clientAlias = fp.getProperty("alias_shchclient");
		String serverAlias = fp.getProperty("alias_shchserver");

		if (fp.containsKey("keyManagerAlgorithm")) {
			keyManagerAlgorithm = fp.getProperty("keyManagerAlgorithm");
		}

		if (fp.containsKey("trustManagerAlgorithm")) {
			trustManagerAlgorithm = fp.getProperty("trustManagerAlgorithm");
		}

		keyPassword = keyPwd;

		String customAddress = ipAddress;

		try {
			keyStore = KeyStore.getInstance("JKS");
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}

		InputStream inputStream = null;
		File jksFile = new File(cafile);

		if (jksFile.isFile()) {
			try {
				inputStream = new FileInputStream(jksFile);
			} catch (FileNotFoundException fnfe) {
				fnfe.printStackTrace();
			}
		} else {
			inputStream = ClientConfig.class.getResourceAsStream(cafile);
		}
		jksFile = null;

		try {
			serverKey = keyStore.getCertificate(serverAlias).getPublicKey();
		} catch (KeyStoreException e3) {
			e3.printStackTrace();
		}

		try {
			Provider p = null;

			System.out.println("usbkeyConfFile===" + usbkeyConfFile);
			p = new SunPKCS11(usbkeyConfFile);
			Security.addProvider(p);
			System.out.println("SunPKCS11===" + p);

			char[] pin = null;

			usbkeyPassword = usbkeyPwd;

			pin = usbkeyPassword.toCharArray();

			KeyStore ks = KeyStore.getInstance("PKCS11", p);
			System.out.println("KeyStore===" + ks);
			ks.load(null, pin);
			System.out.println("ks===" + ks);

			Enumeration aliases = ks.aliases();

			String alias = null;

			alias = (String) aliases.nextElement();

			try {

				usbkeyPassword = usbkeyPwd;

				clientKey = (PrivateKey) ks.getKey(alias,
						usbkeyPassword.toCharArray());
			} catch (KeyStoreException e2) {
				e2.printStackTrace();
			} catch (NoSuchAlgorithmException e2) {
				e2.printStackTrace();
			} catch (UnrecoverableKeyException e2) {
				e2.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @return Returns the clientKey.
	 */
	public PrivateKey getClientKey() {
		return clientKey;
	}

	/**
	 * @return Returns the serverKey.
	 */
	public PublicKey getServerKey() {
		return serverKey;
	}

	/**
	 * @return Returns the keyPassword.
	 */
	public String getKeyPassword() {
		return keyPassword;
	}

	/**
	 * @return Returns the keyStore.
	 */
	public KeyStore getKeyStore() {
		return keyStore;
	}

	/**
	 * @return Returns the storePassword.
	 */
	public String getStorePassword() {
		return storePassword;
	}

	/**
	 * @return Returns the serverUrl.
	 */
	public String getServerUrl() {
		return serverUrl;
	}

	/**
	 * @return Returns the fileServerUrl.
	 */
	public String getFileServerUrl() {
		return fileServerUrl;
	}

	/**
	 * @return Returns the keyManagerAlgorithm.
	 */
	public String getKeyManagerAlgorithm() {
		return keyManagerAlgorithm;
	}

	/**
	 * @return Returns the trustManagerAlgorithm.
	 */
	public String getTrustManagerAlgorithm() {
		return trustManagerAlgorithm;
	}

	/**
	 * @return Returns the proxyHost.
	 */
	public String getProxyHost() {
		return proxyHost;
	}

	/**
	 * @return Returns the proxyPassword.
	 */
	public String getProxyPassword() {
		return proxyPassword;
	}

	/**
	 * @return Returns the proxyPort.
	 */
	public String getProxyPort() {
		return proxyPort;
	}

	/**
	 * @return Returns the proxySet.
	 */
	public String getProxySet() {
		return proxySet;
	}

	/**
	 * @return Returns the proxyUser.
	 */
	public String getProxyUser() {
		return proxyUser;
	}

	/**
	 * @return Returns the cifNo.
	 */
	public String getCifNo() {
		return cifNo;
	}

	/**
	 * @return Returns the ipAddress.
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @return Returns the listenPort.
	 */
	public String getListenPort() {
		return listenPort;
	}

	public String getFileListenPort() {
		return fileListenPort;
	}

	/**
	 * @return Returns the certAlias.
	 */
	public String getCertAlias() {
		return certAlias;
	}

	/**
	 * @return Returns the certFile.
	 */
	public String getCertFile() {
		return certFile;
	}

	/**
	 * @return Returns the clientTimeout.
	 */
	public String getClientTimeout() {
		return clientTimeout;
	}

	/**
	 * @return Returns the serverTimeout.
	 */
	public String getServerTimeout() {
		return serverTimeout;
	}

	/**
	 * @return Returns the requestProcessor.
	 */
	public String getRequestProcessor() {
		return requestProcessor;
	}

	public String getRequestFileProcessor() {
		return requestFileProcessor;
	}

	public static String fetchClientConfig(String propName) {
		CbhbFileProperties cfp = new CbhbFileProperties(configFileName);
		String propValue = cfp.getProperty(propName);
		if (null != propValue) {
			propValue = propValue.trim();
		}
		cfp = null;
		return propValue;
	}

	public static void storeClientConfig(String propName, String propValue) {
		CbhbFileProperties cfp = new CbhbFileProperties(configFileName);
		cfp.put(propName, propValue);
		cfp.save();
		cfp = null;
	}

	final private static String configFileName = "/config/system.properties";

	/**
	 * @return ���� usbkeyConfFile��
	 */
	public String getUsbkeyConfFile() {
		return usbkeyConfFile;
	}

	/**
	 * @param usbkeyConfFile
	 *            Ҫ���õ� usbkeyConfFile��
	 */
	public void setUsbkeyConfFile(String usbkeyConfFile) {
		this.usbkeyConfFile = usbkeyConfFile;
	}

	/**
	 * @return ���� usbkeyFlag��
	 */
	public String getUsbkeyFlag() {
		return usbkeyFlag;
	}

	/**
	 * @param usbkeyFlag
	 *            Ҫ���õ� usbkeyFlag��
	 */
	public void setUsbkeyFlag(String usbkeyFlag) {
		this.usbkeyFlag = usbkeyFlag;
	}

	/**
	 * @return ���� usbkeyPassword��
	 */
	public String getUsbkeyPassword() {
		return usbkeyPassword;
	}

	/**
	 * @param usbkeyPassword
	 *            Ҫ���õ� usbkeyPassword��
	 */
	public void setUsbkeyPassword(String usbkeyPassword) {
		this.usbkeyPassword = usbkeyPassword;
	}

	/**
	 * @return Returns the cbsListenPort.
	 */
	public String getCbsListenPort() {
		return cbsListenPort;
	}

	/**
	 * @return Returns the requestCbsProcessor.
	 */
	public String getRequestCbsProcessor() {
		return requestCbsProcessor;
	}
}