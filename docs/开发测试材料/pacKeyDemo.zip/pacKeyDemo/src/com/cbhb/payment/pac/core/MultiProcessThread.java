package com.cbhb.payment.pac.core;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class MultiProcessThread extends Thread {

    protected static Log log = LogFactory.getLog(MultiProcessThread.class);

    protected static String CHARSET = "utf-8";

    protected static String hostUrl = "http://10.1.208.7:9081/pacServer/connect.do";

    private static PacKeyManager keyManager = null;

    static {
        org.apache.xml.security.Init.init();
        keyManager = new PacKeyManager();
        keyManager.setKeyAlias("pacclienttest");
        keyManager.setServerCertAlias("pacservertest");
        keyManager.setKeyPassword("111111");
        keyManager.setKeystoreFile("/BHIBS/keystore/cbhbclient.jks");
        keyManager.setKeystorePassword("111111");
        keyManager.setKeystoreType("JKS");
    }

    private Map dataMap = null;
    
    private ClientOverHTTP clientOverHTTP = null;

    public MultiProcessThread(Map map, ClientOverHTTP client) {
        super();
        dataMap = map;
        clientOverHTTP = client;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        int iCount = 10000;

        ClientOverHTTP client = new ClientOverHTTP();
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        DecimalFormat df = new DecimalFormat("000000");
        String batchNo = sdf.format(new Date(System.currentTimeMillis()));

        String instSeq = null;
        String instId = "100099";
        String certId = "1000992014081101";
        String pyrAct = "2000713325000168";
        String pyrNam = "2000713325";
        String pyeAct = "1100000000316889";
        String pyeNam = "����";
        String pyeBnk = "402731057238";
        String postscript = "����TEST";

        for (int i = 0; i < iCount; i++) {
            try {
                Map dataMap = new HashMap();

                dataMap.put("transType", "SCHP");

                dataMap.put("instId", instId);
                dataMap.put("certId", certId);
                dataMap.put("pyrAct", pyrAct);
                dataMap.put("pyrNam", pyrNam);
                dataMap.put("pyeAct", pyeAct);
                dataMap.put("pyeNam", pyeNam);
                dataMap.put("pyeBnk", pyeBnk);
                dataMap.put("postscript", postscript);

                Random rnd = new Random(System.currentTimeMillis());
                String amt = String.valueOf(rnd.nextInt(9) + 1);
                instSeq = batchNo + df.format(i);
                dataMap.put("instSeq", instSeq);
                dataMap.put("amt", amt);           
                
                new MultiProcessThread(dataMap, client).start();
                
                if ((i % 1000) == 0) {
                    Thread.sleep(60000);
                }

            } catch (Exception e) {
                log.error("Error occur!", e);
            }
        }

    }

    @Override
    public void run() {
        long curTime = System.currentTimeMillis();
        log.info("Begin run "+this.getId());
        

        try {

            String transType = (String) dataMap.get("transType");

            String requestData = PacUtil.formatData(dataMap, CHARSET);

            String request = sign(requestData, transType);

            String response = clientOverHTTP
                    .issuePac(request, CHARSET, 60000, hostUrl);

            log.info("Trans response:" + response);
        } catch (Exception e) {
            log.error("Error occur !", e);
        }
        
        log.info("Finish run "+this.getId()+", timing :"+ (System.currentTimeMillis() - curTime));

    }

    private String sign(String xmlContent, String transType) {
        String xmlSign = null;

        try {
            log.info("Begin sign :" + transType + ", xml:" + xmlContent);

            Document doc = string2Doc(xmlContent, CHARSET);

            XMLSignature sign = new XMLSignature(doc, "",
                    XMLSignature.ALGO_ID_SIGNATURE_RSA);

            sign.getSignedInfo().addResourceResolver(new OfflineResolver());

            Node messageNode = doc.getElementsByTagName("Message").item(0);
            messageNode.appendChild(sign.getElement());

            Transforms transforms = new Transforms(doc);
            transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);

            sign.addDocument("#" + transType + "Req", transforms,
                    org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);

            // ǩ��
            sign.sign(keyManager.getPrivateKey());

            xmlSign = doc2String(doc, CHARSET);
        } catch (Exception e) {
            log.error("Error occur while sign !", e);
        }

        return xmlSign;
    }

    private boolean verify(String xml) {
        boolean flag = false;

        try {
            Document doc = string2Doc(xml, CHARSET);

            Element nscontext = XMLUtils.createDSctx(doc, "ds",
                    org.apache.xml.security.utils.Constants.SignatureSpecNS);

            Element signElement = (Element) XPathAPI.selectSingleNode(doc,
                    "//ds:Signature[1]", nscontext);

            if (null != signElement) {
                XMLSignature signature = new XMLSignature(signElement, "");

                flag = signature.checkSignatureValue(keyManager
                        .getCertificate().getPublicKey());
            }
        } catch (Exception e) {
            log.error("Error occur while verify !", e);
        }

        return flag;
    }

    /**
     * @param xml
     * @return
     * @throws Exception
     */
    private Document string2Doc(String xml, String charset) throws Exception {

        InputStream is = IOUtils.toInputStream(xml, charset);

        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
                .newInstance();
        docBuilderFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

        Document doc = null;
        if (null != charset) {
            doc = docBuilder.parse(is, charset);
        } else {
            doc = docBuilder.parse(is);
        }
        return doc;
    }

    /**
     * @param doc
     * @return
     * @throws Exception
     */
    private String doc2String(Document doc, String charset) throws Exception {

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer t = tf.newTransformer();
        if (null != charset) {
            t.setOutputProperty("encoding", charset);
        }

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        t.transform(new DOMSource(doc), new StreamResult(bos));
        String xmlStr = null;

        if (null != charset) {
            xmlStr = bos.toString(charset);
        } else {
            xmlStr = bos.toString();
        }
        return xmlStr;
    }

}
