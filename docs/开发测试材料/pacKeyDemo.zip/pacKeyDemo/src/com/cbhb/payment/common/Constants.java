/*
 * @(#)UserManager.java  1.0  Sep 22, 2007
 *
 * Copyright 2007 Client Server International, Inc. All rights Reserved.
 * CSII PROPRIETARY/CONFIDENTAIL. Use is subject to license terms.
 */
package com.cbhb.payment.common;

/**
 * 
 * 
 * Insert the type's description here.
 * 
 * Creation date: (Tue Dec 26 13:26:25 CST 2006)
 * 
 * @author: Auto Generated
 *  
 */
public class Constants {

	public static final String PATTERN = "###,###,##0.00";

	public static final String MD5Algorithm = "MD5withRSA"; // MD5 Algorithm

	public static final String SIGNATURE_VALUE = "SignatureValue"; // ǩ��ֵ����

	public static final String X509_CERTIFICATE = "X509Certificate"; // ֤������
	
	public static final String LOG_PREFIX = "========>";	// ��־��Ϣǰ׺
	
	public static final String SIGNATURE_ALGORITHM_SHA1 = "SHA1withRSA";
}