package com.cbhb.payment.pac.main;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.cbhb.payment.pac.core.ClientOverHTTP;
import com.cbhb.payment.pac.core.PacUtil;

public class FrontendDemo {
	public static final String CHARSET = "utf-8";

	public FrontendDemo() {
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String hostUrl = "http://localhost:9081/pacServer/connect.do";

		int timeout = 60000;

		ClientOverHTTP client = new ClientOverHTTP();

		String sndMsg = null;

		// SCSP
		sndMsg = formatSCSP();

		sndMsg = formatBIQ();

		String response = null;
		try {
			response = client.issuePac(sndMsg, CHARSET, timeout, hostUrl);
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	private static String formatSCSP() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

		DecimalFormat df = new DecimalFormat("000000");
		String batchNo = sdf.format(new Date(System.currentTimeMillis()));

		String instSeq = null;
		// instId��certId��pyrAct��pyrNam����ʵ���ṩ�Ĳ��Բ������
		String instId = "100099";
		String certId = "1000992027032203";
		String pyrAct = "2000713325000168";
		String pyrNam = "2000713325";
		String pyeAct = "1100000000316889";
		String pyeNam = "����";
		String pyeBnk = "402731057238";
		String postscript = "����TEST";

		Map dataMap = new HashMap();

		dataMap.put("transType", "SCSP");

		dataMap.put("instId", instId);
		dataMap.put("certId", certId);
		dataMap.put("pyrAct", pyrAct);
		dataMap.put("pyrNam", pyrNam);
		dataMap.put("pyeAct", pyeAct);
		dataMap.put("pyeNam", pyeNam);
		dataMap.put("pyeBnk", pyeBnk);
		dataMap.put("postscript", postscript);

		Random rnd = new Random(System.currentTimeMillis());
		String amt = String.valueOf(rnd.nextInt(9) + 1);
		instSeq = batchNo + "000001";
		dataMap.put("instSeq", instSeq);
		dataMap.put("amt", amt);

		return PacUtil.formatData(dataMap, CHARSET);
	}

	private static String formatBIQ() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

		DecimalFormat df = new DecimalFormat("000000");
		String batchNo = sdf.format(new Date(System.currentTimeMillis()));

		String instSeq = null;
		// instId��certId��pyrAct��pyrNam����ʵ���ṩ�Ĳ��Բ������
		String instId = "100099";
		String certId = "1000992027032203";
		String pyrAct = "2000713325000168";
		String pyrNam = "2000713325";
		String pyeAct = "1100000000316889";
		String pyeNam = "����";
		String pyeBnk = "402731057238";
		String postscript = "����TEST";
		
		certId = "1000992014081101";

		Map dataMap = new HashMap();

		dataMap.put("transType", "BIQ");

		dataMap.put("instId", instId);
		dataMap.put("certId", certId);
		dataMap.put("pyrAct", pyrAct);
		dataMap.put("pyrNam", pyrNam);
		dataMap.put("pyeAct", pyeAct);
		dataMap.put("pyeNam", pyeNam);
		dataMap.put("pyeBnk", pyeBnk);
		dataMap.put("postscript", postscript);

		Random rnd = new Random(System.currentTimeMillis());
		String amt = String.valueOf(rnd.nextInt(9) + 1);
		instSeq = batchNo + "000001";
		dataMap.put("instSeq", instSeq);
		dataMap.put("amt", amt);

		return PacUtil.formatData(dataMap, CHARSET);
	}

}
