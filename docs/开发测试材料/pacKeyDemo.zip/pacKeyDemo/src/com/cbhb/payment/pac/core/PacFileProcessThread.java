/*
 *
 */
package com.cbhb.payment.pac.core;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.cbhb.data.util.DataUtils;
import com.cbhb.security.signature.SignTool;

/**
 *  
 */
public class PacFileProcessThread extends Thread {
	protected static Log log = LogFactory.getLog(PacFileProcessThread.class);

	private String charset = null;

	private int timeout = 0;

	private String hostUrl = null;

	private Socket socket = null;

	private PacKeyManager keyManager = null;

	/**
     *  
     */
	public PacFileProcessThread(Socket aSocket, PacKeyManager pacKeyManager,
			String aCharset, int aTimeout, String aHostUrl) {
		super();
		socket = aSocket;
		keyManager = pacKeyManager;
		charset = aCharset;
		timeout = aTimeout;
		hostUrl = aHostUrl;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		if (log.isDebugEnabled()) {
			log.debug("PacProcessThread run begin!");
		}

		try {
			if (null != socket) {

				ObjectInputStream ois = new ObjectInputStream(
						socket.getInputStream());

				Map dataMap = (Map) ois.readObject();

				String transType = (String) dataMap.get("transType");
				String instId = "100099";
				String certId = "1000992014081101";
				String fileName = null;
				String fileType = null;
				String fileSHA1 = null;
				String sig = null;
				byte[] fileCont = null;

				if (null != dataMap.get("instId")) {
					instId = (String) dataMap.get("instId");
				}

				if (null != dataMap.get("certId")) {
					certId = (String) dataMap.get("certId");
				}

				if (null != dataMap.get("fileCont")) {
					fileCont = (byte[]) dataMap.get("fileCont");
					fileSHA1 = DataUtils
							.byte2Hex(SignTool.digestSHA1(fileCont));
					sig = SignTool.sign(keyManager.getPrivateKey(),
							fileSHA1.getBytes());
					dataMap.put("fileSHA1", fileSHA1);
					dataMap.put("sig", sig);

				}

				byte[] sndCont = PacUtil.formatPacFile(dataMap, charset);

				Map rspMap = PacUtil.issuePacFile(sndCont, charset, timeout,
						hostUrl);

				if (null != rspMap) {
					dataMap.putAll(rspMap);
				}

				ObjectOutputStream oos = new ObjectOutputStream(
						socket.getOutputStream());
				oos.writeObject(dataMap);
				oos.flush();

			}
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
				log.debug("send data error ", e);
			}
		}

		if (null != socket) {
			try {
				socket.close();
			} catch (IOException e1) {
				log.error("Error while close socket!", e1);
			}
			socket = null;
		}

		if (log.isDebugEnabled()) {
			log.debug("PacProcessThread run end!");
		}

	}

}