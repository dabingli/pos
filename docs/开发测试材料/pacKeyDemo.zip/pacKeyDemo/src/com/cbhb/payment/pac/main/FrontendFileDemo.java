package com.cbhb.payment.pac.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;

import com.cbhb.payment.pac.core.ClientOverHTTP;
import com.cbhb.payment.pac.core.PacUtil;

public class FrontendFileDemo {
	public static final String CHARSET = "utf-8";

	public FrontendFileDemo() {
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String hostUrl = "http://localhost:9081/pacServer/";

		int timeout = 60000;

		ClientOverHTTP client = new ClientOverHTTP();
		String instId = null;
		String certId = null;

		String folder4Upload = null;
		String folder4Download = null;

		String uploadFileName = null;
		String downloadFileName = null;

		Map rcvMap = null;

		byte[] sndCont = null;

		folder4Upload = "d:/BHIBS/files/cbhbpac/upload/";
		folder4Download = "d:/BHIBS/files/cbhbpac/download";

		uploadFileName = "ID100099201702210002.req";
		downloadFileName = "YD100099201606200006.rsp";

		instId = "100099";
		certId = "1000992027032203";

		byte[] uploadSnd = null;

		byte[] downloadSnd = null;

		// ���¼ٶ�folder4Uploadָ����Ŀ¼�´����ļ���ΪuploadFileNameָ����ֵ���ļ�
		sndCont = formatUpload(folder4Upload, uploadFileName, instId, certId);

		try {
			rcvMap = client.issuePacFile(sndCont, CHARSET, 60 * 1000, hostUrl
					+ "uploadFile.do");

			if (null != rcvMap) {
				System.out.println("UploadFile result:" + rcvMap);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		// ���¼ٶ��������ϴ����ļ���ΪdownloadFileNameָ����ֵ���ļ�
		sndCont = formatDownload(downloadFileName, "BPI", instId, certId);

		try {
			rcvMap = client.issuePacFile(sndCont, CHARSET, 60 * 1000, hostUrl
					+ "downloadFile.do");

			if (null != rcvMap) {
				System.out.println("Download result:" + rcvMap);

				byte[] fileCont = (byte[]) rcvMap.get("fileCont");

				if (null != fileCont) {
					FileOutputStream fos = null;
					try {
						fos = new FileOutputStream(new File(folder4Download,
								downloadFileName));
						fos.write(fileCont);
						fos.flush();
						fos.close();
						fos = null;
					} catch (Exception e) {
						e.printStackTrace();
					}

					if (null != fos) {
						try {
							fos.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
						fos = null;
					}

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static byte[] formatUpload(String folder, String fileName,
			String instId, String certId) {
		byte[] sndCont = null;
		String fileSHA1 = null;
		String sigAlg = "SHA1WithRSA";
		byte[] fileCont = null;

		File uploadFile = null;
		FileInputStream fis = null;

		try {

			uploadFile = new File(folder, fileName);
			fis = new FileInputStream(uploadFile);

			fileCont = PacUtil.readAllByteFromStream(fis);

			if (null != fileCont) {
				fileSHA1 = DigestUtils.shaHex(fileCont);
			}

			StringBuffer bufHeader = new StringBuffer();
			bufHeader.append("instId=");
			bufHeader.append(instId);
			bufHeader.append("|");

			bufHeader.append("certId=");
			bufHeader.append(certId);
			bufHeader.append("|");

			bufHeader.append("fileName=");
			bufHeader.append(fileName);
			bufHeader.append("|");

			bufHeader.append("sigAlg=");
			bufHeader.append(sigAlg);
			bufHeader.append("|");

			bufHeader.append("fileSHA1=");
			bufHeader.append(fileSHA1);

			byte[] headerCont = null;
			try {
				headerCont = bufHeader.toString().getBytes(CHARSET);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			String strHeaderLen = PacUtil.formatPckLen(headerCont.length);
			String strTotalLen = PacUtil.formatPckLen(headerCont.length + 8
					+ fileCont.length);

			sndCont = new byte[8 + headerCont.length + 8 + fileCont.length];

			System.arraycopy(strTotalLen.getBytes(), 0, sndCont, 0, 8);

			System.arraycopy(strHeaderLen.getBytes(), 0, sndCont, 8, 8);

			System.arraycopy(headerCont, 0, sndCont, 16, headerCont.length);

			System.arraycopy(fileCont, 0, sndCont, 16 + headerCont.length,
					fileCont.length);

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (null != uploadFile) {
			uploadFile = null;
		}

		if (null != fis) {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			fis = null;
		}

		return sndCont;
	}

	private static byte[] formatDownload(String fileName, String fileType,
			String instId, String certId) {
		byte[] sndCont = null;
		String fileSHA1 = null;
		String sigAlg = "SHA1WithRSA";
		byte[] fileCont = null;

		try {

			StringBuffer bufHeader = new StringBuffer();
			bufHeader.append("instId=");
			bufHeader.append(instId);
			bufHeader.append("|");

			bufHeader.append("certId=");
			bufHeader.append(certId);
			bufHeader.append("|");

			bufHeader.append("fileName=");
			bufHeader.append(fileName);
			bufHeader.append("|");

			bufHeader.append("fileType=");
			bufHeader.append(fileType);
			bufHeader.append("|");

			bufHeader.append("sigAlg=");
			bufHeader.append(sigAlg);

			byte[] headerCont = null;
			try {
				headerCont = bufHeader.toString().getBytes(CHARSET);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			String strHeaderLen = PacUtil.formatPckLen(headerCont.length);
			String strTotalLen = PacUtil.formatPckLen(headerCont.length + 8);

			sndCont = new byte[8 + headerCont.length + 8];

			System.arraycopy(strTotalLen.getBytes(), 0, sndCont, 0, 8);

			System.arraycopy(strHeaderLen.getBytes(), 0, sndCont, 8, 8);

			System.arraycopy(headerCont, 0, sndCont, 16, headerCont.length);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return sndCont;
	}

}
