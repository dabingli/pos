package com.cbhb.payment.pac.main;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.cbhb.payment.pac.core.ClientOverHTTP;
import com.cbhb.payment.pac.core.OfflineResolver;
import com.cbhb.payment.pac.core.PacKeyManager;
import com.cbhb.payment.pac.core.PacUsbkeyManager;
import com.cbhb.payment.pac.core.PacUtil;

public class UsbkeyDemo {
	public static final String CHARSET = "utf-8";

	public UsbkeyDemo() {
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String hostUrl = "http://221.239.93.138:9081/pacServer/connect.do";
		//hostUrl = "https://ebank.cbhb.com.cn/pacServer/connect.do";		

		int timeout = 60000;

		org.apache.xml.security.Init.init();
		
		//ʹ��usbkey֤�������£�cbhbclient.jks�����ڽ���SSL���ӺͶԷ���˷��صı��Ľ�����ǩ
		PacKeyManager pacKeyManager = new PacKeyManager();

		pacKeyManager.setKeyAlias("pacclienttest");
		pacKeyManager.setServerCertAlias("pacservertest");
		pacKeyManager.setKeyPassword("111111");
		pacKeyManager.setKeystoreFile("d:/BHIBS/keystore/cbhbclient.jks");
		pacKeyManager.setKeystorePassword("111111");
		pacKeyManager.setKeystoreType("JKS");

		SSLSocketFactory sslSocketFactory = null;

		// init sslSocketFactory begin
		KeyManagerFactory kf = null;
		try {
			kf = KeyManagerFactory.getInstance("SunX509");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		System.out.println("KeyManagerFactory :" + kf.getAlgorithm());

		try {
			kf.init(pacKeyManager.getKeyStore(), pacKeyManager
					.getKeystorePassword().toCharArray());
		} catch (UnrecoverableKeyException e1) {
			e1.printStackTrace();
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		KeyManager keymanagers[] = kf.getKeyManagers();
		if (null != keymanagers) {
			System.out.println("get keymanagers ok!");
		}

		TrustManagerFactory tf = null;
		try {
			tf = TrustManagerFactory.getInstance("SunX509");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		try {
			tf.init(pacKeyManager.getKeyStore());
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		}
		TrustManager atrustmanagers[] = tf.getTrustManagers();
		if (null != atrustmanagers) {
			System.out.println("get trustmanager ok!");
		}

		SSLContext sslCtx = null;
		try {
			sslCtx = SSLContext.getInstance("TLS");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		try {
			sslCtx.init(keymanagers, atrustmanagers, new SecureRandom());
		} catch (KeyManagementException e1) {
			e1.printStackTrace();
		}

		if (null != sslCtx) {
			System.out.println("get SSLContext ok!");
		}

		sslSocketFactory = sslCtx.getSocketFactory();

		if (null != sslSocketFactory) {
			System.out.println("get sslSocketFactory ok!");
		}
		// init sslSocketFactory end

		ClientOverHTTP client = new ClientOverHTTP();
		client.setSslSocketFactory(sslSocketFactory);
		
		//��������Ϊusbkey��ʼ���룬����Ѿ��޸ģ������޸ĺ�������滻
		String usbkeyPwd="11111111";
		String usbkeyCfgFile = "d:/BHIBS/keystore/FeiTian.cfg";

		PacUsbkeyManager pacUsbkeyManager = new PacUsbkeyManager(usbkeyPwd, usbkeyCfgFile);
		pacUsbkeyManager.load();
		
		String sndMsg = null;
		String sndMsgSigned = null;

		//sndMsg = "<?xml version='1.0' encoding='utf-8'?><Cbhbpac><Message id='fb8ba30587f940c3b15e316dcd1f6ce6'><SCTQReq id='SCTQReq'><version>1.0.0</version><instId>100099</instId><certId>1000992027032203</certId><serialNo>4e6dc3e73acb41e19486868c9b954d9c</serialNo><date>20150311 16:12:52</date></SCTQReq></Message></Cbhbpac>";
		//sndMsgSigned = sign(sndMsg, "SCTQ", pacUsbkeyManager.getClientKey());
		
		// SCSP
		sndMsg = formatSCSP();
		sndMsgSigned = sign(sndMsg, "SCSP", pacUsbkeyManager.getClientKey());

		System.out.println("Signed msg:" + sndMsgSigned);

		String response = null;
		try {
			response = client.issuePac(sndMsgSigned, CHARSET, timeout, hostUrl);

			if (null != response) {
				boolean verifyFlag = verify(response, pacKeyManager
						.getCertificate().getPublicKey());
				System.out.println("Verify result:" + verifyFlag);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}
	
	private static String formatSCSP() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

		DecimalFormat df = new DecimalFormat("000000");
		String batchNo = sdf.format(new Date(System.currentTimeMillis()));

		String instSeq = null;
		//instId��certId��pyrAct��pyrNam����ʵ���ṩ�Ĳ��Բ������
		String instId = "100099";
		String certId = "1000992027032203";
		String pyrAct = "2000713325000168";
		String pyrNam = "2000713325";
		String pyeAct = "1100000000316889";
		String pyeNam = "����";
		String pyeBnk = "402731057238";
		String postscript = "����TEST";

		Map dataMap = new HashMap();

		dataMap.put("transType", "SCSP");

		dataMap.put("instId", instId);
		dataMap.put("certId", certId);
		dataMap.put("pyrAct", pyrAct);
		dataMap.put("pyrNam", pyrNam);
		dataMap.put("pyeAct", pyeAct);
		dataMap.put("pyeNam", pyeNam);
		dataMap.put("pyeBnk", pyeBnk);
		dataMap.put("postscript", postscript);

		Random rnd = new Random(System.currentTimeMillis());
		String amt = String.valueOf(rnd.nextInt(9) + 1);
		instSeq = batchNo + "000001";
		dataMap.put("instSeq", instSeq);
		dataMap.put("amt", amt);

		return PacUtil.formatData(dataMap, CHARSET);
	}

	// ******sign
	private static String sign(String xmlContent, String transType,
			PrivateKey privKey) {
		String xmlSign = null;
		try {

			Document doc = string2Doc(xmlContent, CHARSET);

			XMLSignature sign = new XMLSignature(doc, "",
					XMLSignature.ALGO_ID_SIGNATURE_RSA);

			sign.getSignedInfo().addResourceResolver(new OfflineResolver());

			Node messageNode = doc.getElementsByTagName("Message").item(0);
			messageNode.appendChild(sign.getElement());

			Transforms transforms = new Transforms(doc);
			transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);

			sign.addDocument("#" + transType + "Req", transforms,
					org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);

			// sign***********************************
			sign.sign(privKey);

			xmlSign = doc2String(doc, CHARSET);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return xmlSign;

	}

	private static String doc2String(Document doc, String charset)
			throws Exception {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();
		if (null != charset) {
			t.setOutputProperty("encoding", charset);
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		t.transform(new DOMSource(doc), new StreamResult(bos));
		String xmlStr = null;
		if (null != charset) {
			xmlStr = bos.toString(charset);
		} else {
			xmlStr = bos.toString();
		}
		return xmlStr;
	}

	private static Document string2Doc(String xml, String charset)
			throws Exception {
		InputStream is = IOUtils.toInputStream(xml, charset);
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
				.newInstance();
		docBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		Document doc = null;
		if (null != charset) {
			doc = docBuilder.parse(is, charset);
		} else {
			doc = docBuilder.parse(is);
		}
		return doc;
	}

	private static boolean verify(String xml, PublicKey pubKey) {
		boolean flag = false;
		try {
			Document doc = string2Doc(xml, "UTF-8");
			Element nscontext = XMLUtils.createDSctx(doc, "ds",
					org.apache.xml.security.utils.Constants.SignatureSpecNS);
			Element signElement = (Element) XPathAPI.selectSingleNode(doc,
					"//ds:Signature[1]", nscontext);
			if (null != signElement) {
				org.apache.xml.security.signature.XMLSignature signature = new org.apache.xml.security.signature.XMLSignature(
						signElement, "");

				System.out.println(pubKey);
				flag = signature.checkSignatureValue(pubKey);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
