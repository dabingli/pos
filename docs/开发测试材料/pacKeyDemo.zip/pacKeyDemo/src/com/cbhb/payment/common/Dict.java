/*
 * @(#)MerchantEntry.java  1.0  Sep 22, 2007
 *
 * Copyright 2007 Client Server International, Inc. All rights Reserved.
 * CSII PROPRIETARY/CONFIDENTAIL. Use is subject to license terms.
 */
package com.cbhb.payment.common;

/**
 * MerchantDict
 * Description: �ֵ�
 * <p>
 * Created on Sep 22, 2007
 * Modification history
 * <p>
 * 
 * @Author DanielJia, Internet Banking System Group, CSII
 * 
 * @version 1.0
 * @since 1.0
 */
public class Dict {

	public static final String VERCODE = "_CSII_VERCODE";	// session token name
	public static final String VERCODE_SET = "0123456789";	// session token set
	public static final int VERCODE_SET_LENGTH = 10;	// token set length
	public static final int VERCODE_LENGTH = 4;	// token length
	
	public static final String MASTERID = "MasterID";
	public static final String USERID = "UserID";
	public static final String ACCOUNT = "Account";
	public static final String PASSWORD = "Password";
	public static final String SIGNATURE = "Signature";
	public static final String TRANSNAME = "TransName";
	
	// ����
	public final static String TRANABBR = "TranAbbr";
	public final static String OTRANABBR = "OTranAbbr";
	public final static String MERCSSN = "MercSsn";
	public final static String MERCDTTM = "MercDtTm";
	public final static String TERMSSN = "TermSsn";
	public final static String BTERMSSN = "BTermSsn";
	public final static String ETERMSSN = "ETermSsn";	
	public final static String BTRANDTTM = "BTranDttm";
	public final static String ETRANDTTM = "ETranDttm";		
	public final static String OACQSSN = "OAcqSsn";
	public final static String MERCCODE = "MercCode";
	public final static String TERMCODE = "TermCode";
	public final static String TRANAMT = "TranAmt";
	public final static String MERCSIGN = "MercSign";
	
	public final static String RESPCODE = "RespCode";
	public final static String COMPFLAG = "CompFlag";
	public final static String EPGSIGN = "EPGSign";
	
	public final static String TRANFROM = "TranFrom";
	public final static String PAN = "PAN";
	public final static String PINDATA = "PinData";
	public final static String USERTYPE = "UserType";
	public final static String PAYTIMES = "PayTimes";

	public final static String ACQSSN = "AcqSsn";
	public final static String ADDIAMT = "AddiAmt";
	
	public final static String DYNPASSWD = "DynPasswd";
	public final static String PLAIN = "Plain";
	
	public final static String MERCHNAME = "MerchName";
	public final static String WEBNAME = "WebName";
	public final static String MERCURL = "MercUrl";
	public final static String PANTYPE = "PANType";
	
	public final static String OSTTDATE = "OSttDate";
	public final static String SETTDATE = "SettDate";
	
	public final static String IP = "IP";
	public final static String REMARK1="Remark1";
	public final static String REMARK2="Remark2";
	
	public final static String SETFTYPE="SetFType";
	public final static String SETTFILE="SettFile";
	
	public final static String ORDERSTATELIST="OrderStateList";
	public final static String MERCHANTID="Merc_id"; // ��Ա��
	public final static String MERCHANTNO="Merc_no"; // �̻���
	public final static String IDTYPE = "IdType"; //֤������
	public final static String IDNO = "IdNo"; // ֤������
	public final static String PAYCARDNAME="PayCardName"; // ǩԼ������
	public final static String CHECKFLAG = "CheckFlag"; // �Ƿ���˻���־��
	public final static String CONVERTFEE = "Convert_Fee"; //�̻��������
	
	public final static String REGDATE = "Reg_date";  //ǩԼ����
	public final static String INVALIDDATE = "Invalid_date";  //ʧЧ����
	public final static String LIMITAMTSINGLE = "LimitAmt_single";  //�����޶�
	public final static String LIMITAMTCOUNT = "LimitAmt_count";  //�����޶�

	
}
