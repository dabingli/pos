package com.cbhb.payment.pac.core;

import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PacClientPool {

	protected static Log log = LogFactory.getLog(PacClientPool.class);

	private String hostUrl = null;

	private int timeout = 0;

	private String charset = "utf-8";

	private PacKeyManager keyManager = null;

	private int size = 1;

	public PacClientPool() {
		super();
	}

	void process(Socket socket) {
		try {
			new PacProcessThread(socket, keyManager, charset, timeout, hostUrl)
					.start();
		} catch (Throwable t) {
			log.error("Error occur while process client request!", t);
		}

	}

	public String getHostUrl() {
		return hostUrl;
	}

	public void setHostUrl(String hostUrl) {
		this.hostUrl = hostUrl;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public PacKeyManager getKeyManager() {
		return keyManager;
	}

	public void setKeyManager(PacKeyManager keyManager) {
		this.keyManager = keyManager;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

}
