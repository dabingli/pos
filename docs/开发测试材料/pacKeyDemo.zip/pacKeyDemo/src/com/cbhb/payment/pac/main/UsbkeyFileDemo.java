package com.cbhb.payment.pac.main;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.cbhb.payment.pac.core.ClientOverHTTP;
import com.cbhb.payment.pac.core.OfflineResolver;
import com.cbhb.payment.pac.core.PacKeyManager;
import com.cbhb.payment.pac.core.PacUsbkeyManager;
import com.cbhb.payment.pac.core.PacUtil;
import com.cbhb.security.signature.SignTool;

public class UsbkeyFileDemo {
	public static final String CHARSET = "utf-8";

	public UsbkeyFileDemo() {
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String hostUrl = "http://221.239.93.138:9081/pacFileServer/";

		int timeout = 60000;
		
		
		org.apache.xml.security.Init.init();

		//ʹ��usbkey֤�������£�cbhbclient.jks�����ڽ���SSL���ӺͶԷ���˷��صı��Ľ�����ǩ
		PacKeyManager pacKeyManager = new PacKeyManager();

		pacKeyManager.setKeyAlias("pacclienttest");
		pacKeyManager.setServerCertAlias("pacservertest");
		pacKeyManager.setKeyPassword("111111");
		pacKeyManager.setKeystoreFile("d:/BHIBS/keystore/cbhbclient.jks");
		pacKeyManager.setKeystorePassword("111111");
		pacKeyManager.setKeystoreType("JKS");

		SSLSocketFactory sslSocketFactory = null;

		//init sslSocketFactory begin
		KeyManagerFactory kf = null;
		try {
			kf = KeyManagerFactory.getInstance("SunX509");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		System.out.println("KeyManagerFactory :" + kf.getAlgorithm());

		try {
			kf.init(pacKeyManager.getKeyStore(), pacKeyManager
					.getKeystorePassword().toCharArray());
		} catch (UnrecoverableKeyException e1) {
			e1.printStackTrace();
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		KeyManager keymanagers[] = kf.getKeyManagers();
		if (null != keymanagers) {
			System.out.println("get keymanagers ok!");
		}

		TrustManagerFactory tf = null;
		try {
			tf = TrustManagerFactory.getInstance("SunX509");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		try {
			tf.init(pacKeyManager.getKeyStore());
		} catch (KeyStoreException e1) {
			e1.printStackTrace();
		}
		TrustManager atrustmanagers[] = tf.getTrustManagers();
		if (null != atrustmanagers) {
			System.out.println("get trustmanager ok!");
		}

		SSLContext sslCtx = null;
		try {
			sslCtx = SSLContext.getInstance("TLS");
		} catch (NoSuchAlgorithmException e1) {
			e1.printStackTrace();
		}
		try {
			sslCtx.init(keymanagers, atrustmanagers, new SecureRandom());
		} catch (KeyManagementException e1) {
			e1.printStackTrace();
		}

		if (null != sslCtx) {
			System.out.println("get SSLContext ok!");
		}

		sslSocketFactory = sslCtx.getSocketFactory();

		if (null != sslSocketFactory) {
			System.out.println("get sslSocketFactory ok!");
		}
		// init sslSocketFactory end

		ClientOverHTTP client = new ClientOverHTTP();
		client.setSslSocketFactory(sslSocketFactory);
		
		//��������Ϊusbkey��ʼ���룬����Ѿ��޸ģ������޸ĺ�������滻
		String usbkeyPwd="88888888";
		String usbkeyCfgFile = "d:/BHIBS/keystore/FeiTian.cfg";

		PacUsbkeyManager pacUsbkeyManager = new PacUsbkeyManager(usbkeyPwd, usbkeyCfgFile);
		pacUsbkeyManager.load();

		String uploadPath = "d:/BHIBS/files/cbhbpac/btrn/upload/100099";
		String downloadPath = "d:/BHIBS/files/cbhbpac/btrn/download/100099";
		String fileName = null;

		byte[] sndCont = null;
		Map rspMap = null;

		Map dataMap = null;

		// �ϴ�
		fileName = "ID100099201511250002.req";
		dataMap = prepareUploadFileData(uploadPath, fileName,
				pacUsbkeyManager.getClientKey());

		sndCont = PacUtil.formatPacFile(dataMap, CHARSET);

		try {
			rspMap = client.issuePacFile(sndCont, CHARSET, timeout, hostUrl
					+ "uploadFile.do");

			if (null != rspMap) {
				System.out.println("Upload file result:" + rspMap);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		// ����
		fileName = "YD100099201606200006.rsp";
		dataMap = prepareDownloadFileData(fileName, "BPI",
				pacUsbkeyManager.getClientKey());

		sndCont = PacUtil.formatPacFile(dataMap, CHARSET);

		try {
			rspMap = client.issuePacFile(sndCont, CHARSET, timeout, hostUrl
					+ "downloadFile.do");

			if (null != rspMap) {
				System.out.println("Download file result:" + rspMap);

				byte[] fileCont = (byte[]) rspMap.get("fileCont");
				if (null != fileCont) {
					FileOutputStream fos = new FileOutputStream(new File(
							downloadPath, fileName));
					fos.write(fileCont);
					fos.flush();
					fos.close();
					fos = null;
				}
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}

	}

	// ******sign
	private static String sign(String xmlContent, String transType,
			PrivateKey privKey) {
		String xmlSign = null;
		try {

			Document doc = string2Doc(xmlContent, CHARSET);

			XMLSignature sign = new XMLSignature(doc, "",
					XMLSignature.ALGO_ID_SIGNATURE_RSA);

			sign.getSignedInfo().addResourceResolver(new OfflineResolver());

			Node messageNode = doc.getElementsByTagName("Message").item(0);
			messageNode.appendChild(sign.getElement());

			Transforms transforms = new Transforms(doc);
			transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);

			sign.addDocument("#" + transType + "Req", transforms,
					org.apache.xml.security.utils.Constants.ALGO_ID_DIGEST_SHA1);

			// sign***********************************
			sign.sign(privKey);

			xmlSign = doc2String(doc, CHARSET);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return xmlSign;

	}

	private static String doc2String(Document doc, String charset)
			throws Exception {
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();
		if (null != charset) {
			t.setOutputProperty("encoding", charset);
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		t.transform(new DOMSource(doc), new StreamResult(bos));
		String xmlStr = null;
		if (null != charset) {
			xmlStr = bos.toString(charset);
		} else {
			xmlStr = bos.toString();
		}
		return xmlStr;
	}

	private static Document string2Doc(String xml, String charset)
			throws Exception {
		InputStream is = IOUtils.toInputStream(xml, charset);
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
				.newInstance();
		docBuilderFactory.setNamespaceAware(true);
		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		Document doc = null;
		if (null != charset) {
			doc = docBuilder.parse(is, charset);
		} else {
			doc = docBuilder.parse(is);
		}
		return doc;
	}

	private static boolean verify(String xml, PublicKey pubKey) {
		boolean flag = false;
		try {
			Document doc = string2Doc(xml, "UTF-8");
			Element nscontext = XMLUtils.createDSctx(doc, "ds",
					org.apache.xml.security.utils.Constants.SignatureSpecNS);
			Element signElement = (Element) XPathAPI.selectSingleNode(doc,
					"//ds:Signature[1]", nscontext);
			if (null != signElement) {
				org.apache.xml.security.signature.XMLSignature signature = new org.apache.xml.security.signature.XMLSignature(
						signElement, "");

				System.out.println(pubKey);
				flag = signature.checkSignatureValue(pubKey);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	private static Map prepareUploadFileData(String path, String fileName,
			PrivateKey privKey) {
		Map dataMap = new HashMap();
		
		//instId��certId����ʵ���ṩ�Ĳ��Բ������
		String instId = "100099";
		String certId = "1000992027032203";

		byte[] fileCont = null;
		String fileSHA1 = null;
		String sig = null;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
		String instDate = sdf.format(new Date());

		File file = new File(path, fileName);

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			fileCont = PacUtil.readAllByteFromStream(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (null != fis) {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

			fis = null;
		}

		file = null;

		if (null != fileCont) {
			fileSHA1 = DigestUtils.shaHex(fileCont);
			try {
				sig = SignTool.sign(privKey, fileSHA1.getBytes(CHARSET));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}

		dataMap.put("transType", "UploadFile");
		dataMap.put("instId", instId);
		dataMap.put("certId", certId);
		dataMap.put("instDate", instDate);
		dataMap.put("fileName", fileName);
		dataMap.put("fileCont", fileCont);
		dataMap.put("fileSHA1", fileSHA1);
		dataMap.put("sig", sig);

		return dataMap;
	}

	private static Map prepareDownloadFileData(String fileName,
			String fileType, PrivateKey privKey) {
		Map dataMap = new HashMap();
		
		//instId��certId����ʵ���ṩ�Ĳ��Բ������
		String instId = "100099";
		String certId = "1000992027032203";

		String sig = null;

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
		String instDate = sdf.format(new Date());

		if (null != fileName) {
			try {
				sig = SignTool.sign(privKey, fileName.getBytes(CHARSET));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}

		dataMap.put("transType", "DownloadFile");
		dataMap.put("instId", instId);
		dataMap.put("certId", certId);
		dataMap.put("instDate", instDate);
		dataMap.put("fileName", fileName);
		dataMap.put("fileType", fileType);
		dataMap.put("sig", sig);

		return dataMap;
	}

}
