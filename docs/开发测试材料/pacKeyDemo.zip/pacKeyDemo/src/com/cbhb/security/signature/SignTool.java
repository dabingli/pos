package com.cbhb.security.signature;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.CertStore;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Base64;

import com.cbhb.data.util.DataUtils;
import com.cbhb.payment.common.Constants;

public class SignTool {
	protected static Logger log = Logger.getLogger(SignTool.class);

	static {
		Provider provider = Security
				.getProvider(BouncyCastleProvider.PROVIDER_NAME);

		if (null == provider) {
			provider = new BouncyCastleProvider();
			Security.addProvider(provider);
		}
	}

	public static String sign(PrivateKey key, byte[] content) {
		return sign(key, content, Constants.SIGNATURE_ALGORITHM_SHA1);
	}

	public static String sign(PrivateKey key, byte[] content, String alg) {
		Signature signature = null;
		byte[] signBytes = null;
		String signData = null;

		try {
			signature = Signature.getInstance(alg);

			signature.initSign(key);

			signature.update(content);

			signBytes = signature.sign();

		} catch (NoSuchAlgorithmException nsae) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.sign !", nsae);
			}
		} catch (InvalidKeyException ike) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.sign !", ike);
			}
		} catch (SignatureException se) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.sign !", se);
			}
		}

		if (null != signBytes) {
			signData = DataUtils.byte2Hex(signBytes);
		}

		return signData;
	}

	public static String sign(PrivateKey key, String content, String alg) {
		return sign(key, content.getBytes(), alg);
	}

	public static String sign(PrivateKey key, String content) {
		return sign(key, content.getBytes(), Constants.SIGNATURE_ALGORITHM_SHA1);
	}

	public static boolean verify(PublicKey key, byte[] signData,
			byte[] content, String alg) {
		boolean verifyFlag = false;
		Signature signature = null;
		try {
			signature = Signature.getInstance(alg);
			signature.initVerify(key);
			signature.update(content);
			verifyFlag = signature.verify(signData);
		} catch (NoSuchAlgorithmException nsae) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.verify !", nsae);
			}
		} catch (InvalidKeyException ike) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.verify !", ike);
			}
		} catch (SignatureException se) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.verify !", se);
			}
		}

		return verifyFlag;
	}

	public static boolean verify(PublicKey key, String signData,
			String content, String alg) {
		return verify(key, signData.getBytes(), content.getBytes(), alg);
	}

	public static boolean verify(PublicKey key, String signData, String content) {
		return verify(key, signData.getBytes(), content.getBytes(),
				Constants.SIGNATURE_ALGORITHM_SHA1);
	}

	public static boolean verifyHex(PublicKey key, String signData,
			byte[] content, String alg) {
		return verify(key, DataUtils.hex2Byte(signData), content, alg);
	}

	public static boolean verifyHex(PublicKey key, String signData,
			byte[] content) {
		return verify(key, DataUtils.hex2Byte(signData), content,
				Constants.SIGNATURE_ALGORITHM_SHA1);
	}

	public static Pkcs7Verify verifyPkcs7(String signedData, String signData) {
		if (log.isDebugEnabled()) {
			log.debug("SignTool.verifyPkcs7 :" + signedData + ", " + signData);
		}

		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

		Pkcs7Verify pkcs7Verify = new Pkcs7Verify();
		CMSSignedData sign = null;

		try {

			sign = new CMSSignedData(Base64.decode(signedData));

			if (null != sign.getSignedContent()
					&& null != sign.getSignedContent().getContent()) {

				byte[] content = (byte[]) sign.getSignedContent().getContent();

				if (content.length > 3) {
					if (content[0] == 0 && content[2] == 0) {
						if (log.isDebugEnabled()) {
							log.debug("Big endian");
						}
						content = new String(content, "UTF-16BE").getBytes();
					} else if (content[1] == 0 && content[3] == 0) {
						if (log.isDebugEnabled()) {
							log.debug("Little endian");
						}
						content = new String(content, "UTF-16LE").getBytes();
					}
				}

				pkcs7Verify.setContent(new String(content));
				pkcs7Verify.setDetached(false);

				if (log.isDebugEnabled()) {
					log.debug("SignData:" + new String(content));
				}
			} else if (null != signData) {
				Map hashes = new HashMap();
				byte[] data = signData.getBytes("UTF-16LE");

				byte[] sha1Hash = digestSHA1(data);
				byte[] md5Hash = digestMD5(data);

				hashes.put(CMSSignedDataGenerator.DIGEST_SHA1, sha1Hash);
				hashes.put(CMSSignedDataGenerator.DIGEST_MD5, md5Hash);
				sign = new CMSSignedData(hashes, Base64.decode(signedData));
				pkcs7Verify.setDetached(true);
			}

			if (null != sign) {

				// ���֤����Ϣ
				CertStore certs = sign.getCertificatesAndCRLs("Collection",
						"BC");

				// ���ǩ������Ϣ
				SignerInformationStore signers = sign.getSignerInfos();
				Collection c = signers.getSigners();

				Iterator it = c.iterator();

				X509Certificate cert = null;

				// ���ж��ǩ������Ϣʱ��Ҫȫ����֤
				while (it.hasNext()) {
					SignerInformation signer = (SignerInformation) it.next();

					// ֤����
					Collection certCollection = certs.getCertificates(signer
							.getSID());
					Iterator certIt = certCollection.iterator();

					cert = (X509Certificate) certIt.next();

					byte[] signature = signer.getSignature();
					String signatureStr = DataUtils.byte2Hex(signature);

					if (log.isDebugEnabled()) {
						log.debug("Signaure : length--> " + signature.length
								+ ", hex content-->" + signatureStr);
					}

					pkcs7Verify.setSignature(signatureStr);

					// ��֤����ǩ��
					if (signer.verify(cert.getPublicKey(), "BC")) {
						if (log.isDebugEnabled()) {
							log.debug("Verify ok:"
									+ cert.getSubjectDN().getName());
						}
						pkcs7Verify.setVerified(true);
						pkcs7Verify.setCert(cert);

					} else {
						if (log.isDebugEnabled()) {
							log.debug("Verify fail:"
									+ cert.getSubjectDN().getName());
						}
						pkcs7Verify.setVerified(false);
						break;
					}
				}
			}
		} catch (Exception e) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.verifyPkcs7 !", e);
			}
		}

		return pkcs7Verify;
	}

	public static boolean testVerifyPkcs7() {
		boolean flag = false;

		byte[] data = null;
		try {
			data = "CifNo2000012006LoginNameauditor1Password641985"
					.getBytes("UTF-16LE");
		} catch (UnsupportedEncodingException e1) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.testVerifyPkcs7 !", e1);
			}
		}

		try {
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

			// attached
			// String testData =
			// "MIIH8wYJKoZIhvcNAQcCoIIH5DCCB+ACAQExCzAJBgUrDgMCGgUAMGsGCSqGSIb3DQEHAaBeBFxDAGkAZgBOAG8AMgAwADAAMAAwADEAMgAwADAANgBMAG8AZwBpAG4ATgBhAG0AZQBhAHUAZABpAHQAbwByADEAUABhAHMAcwB3AG8AcgBkADYANAAxADkAOAA1AKCCBn8wggJ7MIIB5KADAgECAgQ8/IxeMA0GCSqGSIb3DQEBBQUAMCAxCzAJBgNVBAYTAkNOMREwDwYDVQQKEwhDRkNBIFJDQTAeFw0wNDA4MTAwODM2MzdaFw0xNDA3MjUxNjAwMDBaMCQxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0EwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBANiuznQzuGrzLQvMWN83dQ9DMaIGDWQuKc+olxLHuhFd7LXlaksswu2Fx+n0af/u5ea00vpq2Gv3VhfOsHdFynndTfOpJwYT2HaS0VDdI11k/pz9VJD7bukBXFZFQL4XqmZSyej6N3WZ+1iOEpFXzK8JGlJXocPOEsrzfFuSgJ+JAgMBAAGjgb0wgbowQgYDVR0fBDswOTA3oDWgM6QxMC8xCzAJBgNVBAYTAkNOMREwDwYDVQQKEwhDRkNBIFJDQTENMAsGA1UEAxMEQ1JMMTALBgNVHQ8EBAMCAQYwHwYDVR0jBBgwFoAUAJo08lH5UxRhdG5yoQbex4FwG7wwHQYDVR0OBBYEFEZy3CVynwJOVYO1gPkL2+mTs/RFMAwGA1UdEwQFMAMBAf8wGQYJKoZIhvZ9B0EABAwwChsEVjYuMAMCBJAwDQYJKoZIhvcNAQEFBQADgYEAnr2XRjUr5rIS+iPMEd/OjMx/RrRpAxoRuKKX5ElDyW/BYdk55pFNwk7HKI+hDkNmqES6xdq8U9fgn+YTcfk8KdXm0Xu1I7u8SC6GzybYhfGs5kKkqYIlV6811X3HSb14Prb01UkZ/rzetozHf0W3gdAVotP4RdudIBa9h6Y/I5YwggP8MIIDZaADAgECAhB+Q3V1tXilsXGmx0HSH9qjMA0GCSqGSIb3DQEBBQUAMCQxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0EwHhcNMTAxMDE4MDkxOTQwWhcNMTIxMDE4MDkxOTQwWjCBqDELMAkGA1UEBhMCQ04xFTATBgNVBAoTDENGQ0EgVEVTVCBDQTEPMA0GA1UECxMGQ0NGQ0NCMRQwEgYDVQQLEwtFbnRlcnByaXNlczFbMFkGA1UEAx5SADAANAAxAEAAOAAxADIAMAAxADEAMAAyADAAMAA3ADYAMAA2AEBZKW0lXgJ/1FuHWQ1UCGdQZZlnCZZQUWxT+ABAADAAMAAwADAAMAAwADAAODCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAkVhNDZSujMJ6P7bhB9SwVr8N+QLovILmURw6pKrVte1DXdh3/FmkV67c4iU2zrqXP3Fl6xPw/BKkSScNNQkacx3khigXtwZ17mS5+shnM1c2tm2PdYxStfFeqsv7SimaWli8v90g3Pg2fwreDzHGKcVxUYsjWG0q1aGstTkS2usCAwEAAaOCAagwggGkMB8GA1UdIwQYMBaAFEZy3CVynwJOVYO1gPkL2+mTs/RFMB0GA1UdDgQWBBRDo/3RrnYonPMBWhEIEzEdyIYY9DALBgNVHQ8EBAMCBaAwDAYDVR0TBAUwAwEBADA7BgNVHSUENDAyBggrBgEFBQcDAQYIKwYBBQUHAwIGCCsGAQUFBwMDBggrBgEFBQcDBAYIKwYBBQUHAwgwgfAGA1UdHwSB6DCB5TBPoE2gS6RJMEcxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0ExDDAKBgNVBAsTA0NSTDETMBEGA1UEAxMKY3JsMTI3XzEwNzCBkaCBjqCBi4aBiGxkYXA6Ly90ZXN0bGRhcC5jZmNhLmNvbS5jbjozODkvQ049Y3JsMTI3XzEwNyxPVT1DUkwsTz1DRkNBIFRFU1QgQ0EsQz1DTj9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Y2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwFwYDKlYBBBATDkNCSEIyMDAwMDEyMDA2MA0GCSqGSIb3DQEBBQUAA4GBAMi5XVgg5EKwX0GdfwtLsgBJpHH9C7e3anHBHpI9ZFMWz8K4G5fiPPQFG/nBZjEqD/4zAZe5dqcXBQyPQ4K1bsggs8Yb5ufcR4nT4utCpOXlfQWSZWcDk+M2ywyUvPpvk/Z3fU7r9cCsqXNF9r7cy66KQJThvlnsfKkcpLvPF86zMYHdMIHaAgEBMDgwJDELMAkGA1UEBhMCQ04xFTATBgNVBAoTDENGQ0EgVEVTVCBDQQIQfkN1dbV4pbFxpsdB0h/aozAJBgUrDgMCGgUAMA0GCSqGSIb3DQEBAQUABIGAhCZoqhZTHdPdac4P2nIEA5KygNTSjz4fRlcef8bDXHz7tywIhE5Y835ebnEMMOUQ1xHuqp8Je61il0aQJtsLBqX/oZm6PtPkgYTDFF1ncf/oR5r+tWwoeUdTZQmtPRBzH8DmOGFBp7djMnGt8auukEwAet8+EgztGb3floTQzUs=";

			// detached
			String testData = "MIIHkwYJKoZIhvcNAQcCoIIHhDCCB4ACAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHAaCCBn8wggJ7MIIB5KADAgECAgQ8/IxeMA0GCSqGSIb3DQEBBQUAMCAxCzAJBgNVBAYTAkNOMREwDwYDVQQKEwhDRkNBIFJDQTAeFw0wNDA4MTAwODM2MzdaFw0xNDA3MjUxNjAwMDBaMCQxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0EwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBANiuznQzuGrzLQvMWN83dQ9DMaIGDWQuKc+olxLHuhFd7LXlaksswu2Fx+n0af/u5ea00vpq2Gv3VhfOsHdFynndTfOpJwYT2HaS0VDdI11k/pz9VJD7bukBXFZFQL4XqmZSyej6N3WZ+1iOEpFXzK8JGlJXocPOEsrzfFuSgJ+JAgMBAAGjgb0wgbowQgYDVR0fBDswOTA3oDWgM6QxMC8xCzAJBgNVBAYTAkNOMREwDwYDVQQKEwhDRkNBIFJDQTENMAsGA1UEAxMEQ1JMMTALBgNVHQ8EBAMCAQYwHwYDVR0jBBgwFoAUAJo08lH5UxRhdG5yoQbex4FwG7wwHQYDVR0OBBYEFEZy3CVynwJOVYO1gPkL2+mTs/RFMAwGA1UdEwQFMAMBAf8wGQYJKoZIhvZ9B0EABAwwChsEVjYuMAMCBJAwDQYJKoZIhvcNAQEFBQADgYEAnr2XRjUr5rIS+iPMEd/OjMx/RrRpAxoRuKKX5ElDyW/BYdk55pFNwk7HKI+hDkNmqES6xdq8U9fgn+YTcfk8KdXm0Xu1I7u8SC6GzybYhfGs5kKkqYIlV6811X3HSb14Prb01UkZ/rzetozHf0W3gdAVotP4RdudIBa9h6Y/I5YwggP8MIIDZaADAgECAhB+Q3V1tXilsXGmx0HSH9qjMA0GCSqGSIb3DQEBBQUAMCQxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0EwHhcNMTAxMDE4MDkxOTQwWhcNMTIxMDE4MDkxOTQwWjCBqDELMAkGA1UEBhMCQ04xFTATBgNVBAoTDENGQ0EgVEVTVCBDQTEPMA0GA1UECxMGQ0NGQ0NCMRQwEgYDVQQLEwtFbnRlcnByaXNlczFbMFkGA1UEAx5SADAANAAxAEAAOAAxADIAMAAxADEAMAAyADAAMAA3ADYAMAA2AEBZKW0lXgJ/1FuHWQ1UCGdQZZlnCZZQUWxT+ABAADAAMAAwADAAMAAwADAAODCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAkVhNDZSujMJ6P7bhB9SwVr8N+QLovILmURw6pKrVte1DXdh3/FmkV67c4iU2zrqXP3Fl6xPw/BKkSScNNQkacx3khigXtwZ17mS5+shnM1c2tm2PdYxStfFeqsv7SimaWli8v90g3Pg2fwreDzHGKcVxUYsjWG0q1aGstTkS2usCAwEAAaOCAagwggGkMB8GA1UdIwQYMBaAFEZy3CVynwJOVYO1gPkL2+mTs/RFMB0GA1UdDgQWBBRDo/3RrnYonPMBWhEIEzEdyIYY9DALBgNVHQ8EBAMCBaAwDAYDVR0TBAUwAwEBADA7BgNVHSUENDAyBggrBgEFBQcDAQYIKwYBBQUHAwIGCCsGAQUFBwMDBggrBgEFBQcDBAYIKwYBBQUHAwgwgfAGA1UdHwSB6DCB5TBPoE2gS6RJMEcxCzAJBgNVBAYTAkNOMRUwEwYDVQQKEwxDRkNBIFRFU1QgQ0ExDDAKBgNVBAsTA0NSTDETMBEGA1UEAxMKY3JsMTI3XzEwNzCBkaCBjqCBi4aBiGxkYXA6Ly90ZXN0bGRhcC5jZmNhLmNvbS5jbjozODkvQ049Y3JsMTI3XzEwNyxPVT1DUkwsTz1DRkNBIFRFU1QgQ0EsQz1DTj9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2U/b2JqZWN0Y2xhc3M9Y1JMRGlzdHJpYnV0aW9uUG9pbnQwFwYDKlYBBBATDkNCSEIyMDAwMDEyMDA2MA0GCSqGSIb3DQEBBQUAA4GBAMi5XVgg5EKwX0GdfwtLsgBJpHH9C7e3anHBHpI9ZFMWz8K4G5fiPPQFG/nBZjEqD/4zAZe5dqcXBQyPQ4K1bsggs8Yb5ufcR4nT4utCpOXlfQWSZWcDk+M2ywyUvPpvk/Z3fU7r9cCsqXNF9r7cy66KQJThvlnsfKkcpLvPF86zMYHdMIHaAgEBMDgwJDELMAkGA1UEBhMCQ04xFTATBgNVBAoTDENGQ0EgVEVTVCBDQQIQfkN1dbV4pbFxpsdB0h/aozAJBgUrDgMCGgUAMA0GCSqGSIb3DQEBAQUABIGAhCZoqhZTHdPdac4P2nIEA5KygNTSjz4fRlcef8bDXHz7tywIhE5Y835ebnEMMOUQ1xHuqp8Je61il0aQJtsLBqX/oZm6PtPkgYTDFF1ncf/oR5r+tWwoeUdTZQmtPRBzH8DmOGFBp7djMnGt8auukEwAet8+EgztGb3floTQzUs=";

			Map hashes = new HashMap();
			byte[] sha1Hash = digestSHA1(data);
			byte[] md5Hash = digestMD5(data);

			hashes.put(CMSSignedDataGenerator.DIGEST_SHA1, sha1Hash);
			hashes.put(CMSSignedDataGenerator.DIGEST_MD5, md5Hash);

			CMSSignedData sign = new CMSSignedData(Base64.decode(testData));

			if (sign.getSignedContent() != null) {
				System.out
						.println(sign.getSignedContent().getClass().getName());

				byte[] content = (byte[]) sign.getSignedContent().getContent();
				System.out.println(content.length);
				content = new String(content, "UTF-16LE").getBytes();
				System.out.println(content.length);
				System.out.println(new String(content));
			} else {
				System.out.println("Detached!");
				sign = new CMSSignedData(hashes, Base64.decode(testData));
			}

			// ���֤����Ϣ
			CertStore certs = sign.getCertificatesAndCRLs("Collection", "BC");

			// ���ǩ������Ϣ
			SignerInformationStore signers = sign.getSignerInfos();
			Collection c = signers.getSigners();

			System.out.println(c.size());
			Iterator it = c.iterator();

			// ���ж��ǩ������Ϣʱ��Ҫȫ����֤
			while (it.hasNext()) {
				SignerInformation signer = (SignerInformation) it.next();
				System.out.println(signer.getDigestAlgOID());

				// ֤����
				Collection certCollection = certs.getCertificates(signer
						.getSID());
				Iterator certIt = certCollection.iterator();
				X509Certificate cert = (X509Certificate) certIt.next();

				System.out.println(cert.getSubjectX500Principal().getName(
						"RFC1779"));

				// ��֤����ǩ��
				if (signer.verify(cert.getPublicKey(), "BC")) {
					flag = true;
				} else {
					flag = false;
				}
			}

		} catch (Exception e) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.testVerifyPkcs7 !", e);
			}
		}

		return flag;
	}

	public static byte[] digestSHA1(byte[] data) {
		MessageDigest sha1 = null;
		byte[] digest = null;

		try {
			sha1 = MessageDigest.getInstance("SHA1");
			digest = sha1.digest(data);
		} catch (NoSuchAlgorithmException nsae) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.digestSHA1 !", nsae);
			}
		}

		return digest;
	}

	public static byte[] digestMD5(byte[] data) {
		MessageDigest md5 = null;
		byte[] digest = null;

		try {
			md5 = MessageDigest.getInstance("MD5");
			digest = md5.digest(data);
		} catch (NoSuchAlgorithmException nsae) {
			if (log.isEnabledFor(Priority.ERROR)) {
				log.error("Error occur while SignTool.digestMD5 !", nsae);
			}
		}

		return digest;
	}

	public static byte[] getCertThumbprint(X509Certificate cert) {
		byte[] thumbprint = null;
		try {
			thumbprint = digestSHA1(cert.getEncoded());
		} catch (CertificateEncodingException e) {
		}
		return thumbprint;
	}

	public static void main(String[] args) {
		System.out.println(DataUtils.byte2Hex(digestMD5("aadfasfsafa"
				.getBytes())));
		System.out.println(DataUtils.byte2Hex(digestSHA1("aadfasfsafa"
				.getBytes())));
	}
}