package com.cbhb.security.signature;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class CertTool {

	public static void main(String[] args) {

	}

	public static boolean checkCert(String cifNo, File certFile) {
		boolean flag = false;

		return flag;
	}

	public static boolean checkCert(String content, String subject,
			String issuer) {
		boolean flag = false;

		X509Certificate cert = resolveCert(content);

		if (null != cert) {
			if (cert.getSubjectDN().getName().equals(subject)) {
				if (null != issuer) {
					if (issuer.indexOf(cert.getIssuerDN().getName()) != -1) {
						flag = true;
					}
				} else {
					flag = true;
				}
			}
		}

		return flag;
	}

	public static X509Certificate resolveCert(String content) {
		CertificateFactory cf = null;
		X509Certificate cert = null;
		InputStream is = null;

		try {
			cf = CertificateFactory.getInstance("X.509");
			is = new ByteArrayInputStream(prepareCertData(content));
			cert = (X509Certificate) cf.generateCertificate(is);
			is.close();
			is = null;
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (null != is) {
			try {
				is.close();
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
			is = null;
		}

		return cert;

	}
	
	private static byte[] prepareCertData(String line) {

		String subStr1 = line.substring(0, CERT_PREFIX.length());
		String subStr2 = line.substring(line.length() - CERT_SUFFIX.length());

		String tmpStr = null;

		if (subStr1.equalsIgnoreCase(CERT_PREFIX)) {
			tmpStr = line.substring(CERT_PREFIX.length());
		} else {
			tmpStr = line;
		}

		if (subStr2.equalsIgnoreCase(CERT_SUFFIX)) {
			tmpStr = tmpStr.substring(0, tmpStr.length() - CERT_SUFFIX.length());
		}

		tmpStr = tmpStr.trim();

		StringTokenizer st = new StringTokenizer(tmpStr, " ");
		List lines = new ArrayList();
		String curLine = null;
		while (st.hasMoreTokens()) {
			curLine = st.nextToken();
			if (!"".equals(curLine.trim())) {
				lines.add(curLine);
			}
		}
		StringBuffer buf = new StringBuffer();

		buf.append(CERT_PREFIX);
		buf.append("\r\n");
		for(int i=0;i<lines.size();i++){
			buf.append(lines.get(i));
			buf.append("\r\n");
		}
		buf.append(CERT_SUFFIX);

		byte[] bSingleLine = buf.toString().getBytes();

		return bSingleLine;
	}
	
	private static final String CERT_PREFIX = "-----BEGIN CERTIFICATE-----";
	
	private static final String CERT_SUFFIX = "-----END CERTIFICATE-----";

}