package com.cbhb.security.crypto;

public interface CBHBCrypto {
	String encrypt(String plantText);

	String decrypt(String cipherText);
}
