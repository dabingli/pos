/*
 *
 */
package com.cbhb.security.signature;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 *  
 */
public class CycleBlock {
	private List items = new ArrayList();

	public void addItem(HiddenItem item) {
		items.add(item);
	}

	public HiddenItem getItem(int index) {
		return (HiddenItem) items.get(index);
	}

	public List getItems() {
		return items;
	}

	public boolean removeItem(HiddenItem item) {
		return items.remove(item);
	}

	public HiddenItem removeItem(int index) {
		return (HiddenItem) items.remove(index);
	}

	public void setItems(List items) {
		this.items = items;
	}
	
	public void clear(){
		items.clear();
	}
	
	public int size(){
		return items.size();
	}
}