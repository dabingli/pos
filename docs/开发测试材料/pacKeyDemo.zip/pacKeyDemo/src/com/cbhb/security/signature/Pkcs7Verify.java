/*
 *
 */
package com.cbhb.security.signature;

import java.security.cert.X509Certificate;

/**
 * 
 *
 */
public class Pkcs7Verify {

	/**
	 * 
	 */
	public Pkcs7Verify() {
		super();
	}
	
	private boolean detached = false;
	
	private boolean verified = false;
	
	private String content = null;
	
	private String signature=null;
	
	private X509Certificate cert =null;

	/**
	 * @return Returns the cert.
	 */
	public X509Certificate getCert() {
		return cert;
	}
	/**
	 * @param cert The cert to set.
	 */
	public void setCert(X509Certificate cert) {
		this.cert = cert;
	}
	/**
	 * @return Returns the content.
	 */
	public String getContent() {
		return content;
	}
	/**
	 * @param content The content to set.
	 */
	public void setContent(String content) {
		this.content = content;
	}
	/**
	 * @return Returns the detached.
	 */
	public boolean isDetached() {
		return detached;
	}
	/**
	 * @param detached The detached to set.
	 */
	public void setDetached(boolean detached) {
		this.detached = detached;
	}
	/**
	 * @return Returns the verified.
	 */
	public boolean isVerified() {
		return verified;
	}
	/**
	 * @param verified The verified to set.
	 */
	public void setVerified(boolean verified) {
		this.verified = verified;
	}
	/**
	 * @return Returns the signature.
	 */
	public String getSignature() {
		return signature;
	}
	/**
	 * @param signature The signature to set.
	 */
	public void setSignature(String signature) {
		this.signature = signature;
	}
}
