/*
 *
 */
package com.cbhb.security.signature;

/**
 *  
 */
public class HiddenItem {

	private String itemClass = null;

	private String itemDefault = null;

	private String itemKey = null;

	private String itemMessage = null;

	public String getItemClass() {
		return itemClass;
	}

	public String getItemDefault() {
		return itemDefault;
	}

	public String getItemKey() {
		return itemKey;
	}
	public String getItemMessage() {
		return itemMessage;
	}

	public void setItemClass(String itemClass) {
		this.itemClass = itemClass;
	}

	public void setItemDefault(String itemDefault) {
		this.itemDefault = itemDefault;
	}

	public void setItemKey(String itemKey) {
		this.itemKey = itemKey;
	}
	public void setItemMessage(String itemMessage) {
		this.itemMessage = itemMessage;
	}
}