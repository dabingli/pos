/*
 *
 */
package com.cbhb.security.crypto;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.bouncycastle.jce.provider.BouncyCastleProvider;


/**
 * 
 *  
 */
public class CBHBCryptUtil {

	/**
	 * ����RSA�ķǶԳƽ���
	 * 
	 * @param cipherContent
	 *            ����
	 * @param aKey
	 *            ��Կ
	 * @return ����
	 */
	public static byte[] decryptRSA(byte[] cipherContent, Key aKey) {
		byte[] plainContent = null;

		try {
			Cipher cipher = Cipher.getInstance("RSA", getBCProvider());

			cipher.init(Cipher.DECRYPT_MODE, aKey);

			plainContent = cipher.doFinal(cipherContent);

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}

		return plainContent;
	}

	/**
	 * ����RSA�ķǶԳƽ���
	 * 
	 * @param cipherContent
	 *            ����
	 * @param keyFileName
	 *            ��Կ�ļ���
	 * @param keyType
	 *            ��Կ���� 0 ˽Կ 1 ��Կ
	 * @return ����
	 */
	public static byte[] decryptRSA(byte[] cipherContent, String keyFileName,
			int keyType) {
		Key aKey = readKeyFromFile(keyFileName, keyType);

		return decryptRSA(cipherContent, aKey);
	}

	/**
	 * ����RSA�ķǶԳƼ���
	 * 
	 * @param plainContent
	 *            ����
	 * @param aKey
	 *            ��Կ
	 * @return
	 */
	public static byte[] encryptRSA(byte[] plainContent, Key aKey) {
		byte[] cipherContent = null;

		try {
			Cipher cipher = Cipher.getInstance("RSA", getBCProvider());

			cipher.init(Cipher.ENCRYPT_MODE, aKey);

			cipherContent = cipher.doFinal(plainContent);

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		}

		return cipherContent;
	}

	/**
	 * ����RSA�ķǶԳƼ���
	 * 
	 * @param plainContent
	 *            ����
	 * @param keyFileName
	 *            ��Կ�ļ���
	 * @param keyType
	 *            ��Կ���� 0 ˽Կ 1 ��Կ
	 * @return
	 */
	public static byte[] encryptRSA(byte[] plainContent, String keyFileName,
			int keyType) {
		Key aKey = readKeyFromFile(keyFileName, keyType);

		return encryptRSA(plainContent, aKey);

	}

	public static void saveKeyPair(KeyPair key) {
		BufferedOutputStream bos = null;

		try {
			bos = new BufferedOutputStream(new FileOutputStream(
					"d:/RsaLogin.key"));
			byte[] keyContent = key.getPrivate().getEncoded();
			bos.write(keyContent);

			bos.flush();

			bos.close();

			bos = null;

			bos = new BufferedOutputStream(new FileOutputStream(
					"d:/RsaPublicKey.key"));
			keyContent = key.getPublic().getEncoded();
			bos.write(keyContent);

			bos.flush();

			bos.close();

			bos = null;
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		if (null != bos) {
			try {
				bos.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}

			bos = null;
		}
	}

	public static KeyPair genKeyPair() {
		KeyPairGenerator keyGen = null;
		try {
			keyGen = KeyPairGenerator.getInstance("RSA", getBCProvider());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		keyGen.initialize(1024);
		KeyPair key = keyGen.generateKeyPair();

		return key;
	}

	public static Provider getBCProvider() {
		Provider provider = Security
				.getProvider(BouncyCastleProvider.PROVIDER_NAME);

		if (null == provider) {
			provider = new BouncyCastleProvider();
			Security.addProvider(provider);
		}
		return provider;
	}

	public static void main(String[] args) {
		//genKeyPair();
		testRSA();
	}

	public static Key readKeyFromFile(String keyFileName, int keyType) {
		KeyFactory keyFactory = null;

		Key aKey = null;

		BufferedInputStream bis = null;
		try {
			keyFactory = KeyFactory.getInstance("RSA", getBCProvider());

			bis = new BufferedInputStream(new FileInputStream(keyFileName));

			byte[] content = new byte[bis.available()];

			int readByte = 0;
			int totalReadByte = 0;

			while (totalReadByte < content.length) {
				readByte = bis.read(content, totalReadByte, content.length
						- totalReadByte);
				if (readByte == -1) {
					break;
				} else {
					totalReadByte = totalReadByte + readByte;
				}
			}

			bis.close();

			bis = null;

			//private key
			if (keyType == 0) {
				PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(content);
				aKey = keyFactory.generatePrivate(priPKCS8);
			} else {
				X509EncodedKeySpec bobPubKeySpec = new X509EncodedKeySpec(
						content);
				aKey = keyFactory.generatePublic(bobPubKeySpec);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		}

		if (null != bis) {

			try {
				bis.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			bis = null;
		}

		return aKey;

	}

	public static void testRSA() {
		String plain = "abcdefg��æ��¦çݧާߤ�����������";
		String decryptKeyFileName = "d:/RsaLogin.key";
		String encryptKeyFileName = "d:/RsaPublicKey.key";

		Key encryptKey = readKeyFromFile(encryptKeyFileName, 1);
		Key decryptKey = readKeyFromFile(decryptKeyFileName, 0);

		long timeBegin = 0L;
		long timeEncrypt = 0L;
		long timeDecrypt = 0L;

		try {
			timeBegin = System.currentTimeMillis();
			byte[] cipherBytes = encryptRSA(plain.getBytes("UTF-8"), encryptKey);
			timeEncrypt = System.currentTimeMillis();
			byte[] plainBytes = decryptRSA(cipherBytes, decryptKey);
			timeDecrypt = System.currentTimeMillis();

			System.out.println("Original plain : " + plain);
			System.out.println("Encryption takes(ms) : "
					+ (timeEncrypt - timeBegin));
			System.out.println("Decryption takes(ms) : "
					+ (timeDecrypt - timeEncrypt));
			System.out.println("Processed plain : "
					+ new String(plainBytes, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}