/*
 *
 *
 */
package com.cbhb.data.util;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * 
 *  
 */
public class PropertiesDict implements Dictionary {

	private String dictFileNames = null;

	private Map dictFileMap = new HashMap();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bh.ibs.core.Dictionary#resolveDict(java.lang.String,
	 *      java.util.Locale)
	 */
	public String resolveDict(String aWord, Locale locale) {
		String dictValue = null;

		if (null != dictFileNames) {
			StringTokenizer st = new StringTokenizer(dictFileNames, ";");
			String token = null;
			String key = null;
			
			CbhbFileProperties fp = null ;		

			while (st.hasMoreTokens()) {
				token = st.nextToken();
				key = token;

				if (!token.endsWith(".properties")) {
					if (null != locale) {
						key = token + locale.toString() + ".properties";
					}else{
						key = token + ".properties";
					}
				}

				if (dictFileMap.containsKey(key)) {
					fp = (CbhbFileProperties) dictFileMap.get(key);
				} else {
					fp = new CbhbFileProperties(key, 1);
					dictFileMap.put(key, fp);
				}

				if (fp.containsKey(aWord)) {
					dictValue = fp.getProperty(aWord);
					break;
				}
			}
		}

		if (null == dictValue) {
			dictValue = aWord;
		}

		return dictValue;
	}

	public String getDictFileNames() {
		return dictFileNames;
	}

	public void setDictFileNames(String dictFileNames) {
		this.dictFileNames = dictFileNames;
	}
}