/*
 *
 */
package com.cbhb.data.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *  
 */
public class CbhbFileProperties extends Properties {

	protected static Log log = LogFactory.getLog(CbhbFileProperties.class);

	private String resource = null;

	/**
	 *  
	 */
	public CbhbFileProperties() {
		super();
	}

	/**
	 * @param defaults
	 */
	public CbhbFileProperties(Properties defaults) {
		super(defaults);
	}

	public CbhbFileProperties(String resource) {
		this(resource, 0);

	}

	public CbhbFileProperties(String resource, int flag) {
		super();
		this.resource = resource;

		if (0 == flag) {
			try {
				InputStream is = getClass().getResourceAsStream(resource);
				if (null != is) {
					load(is);
				}
			} catch (IOException e) {
				if (log.isErrorEnabled()) {
					log.error("Error occur !", e);
				}
			}
		} else {
			ArrayList lines = readLines();

			if (null != lines) {
				String line = null;
				int pos = -1;
				for (int i = 0; i < lines.size(); i++) {
					line = (String) lines.get(i);
					if (!line.startsWith("#")) {
						pos = line.indexOf('=');
						if (pos != -1) {
							this.setProperty(line.substring(0, pos).trim(),
									line.substring(pos + 1).trim());
						}
					}

				}
				lines.clear();
				lines = null;
			}
		}
	}

	public void save() {
		if (null != resource) {
			String fileName = this.getClass().getResource(resource).getFile();

			if (null != fileName) {
				ArrayList list = readLines();

				if (null != list && list.size() > 0) {
					PrintWriter writer = null;
					try {
						writer = new PrintWriter(new OutputStreamWriter(
								new FileOutputStream(fileName)));

						String line = null;
						String key = null;
						String value = null;
						StringBuffer updateLine = null;
						int pos = -1;

						for (int i = 0; i < list.size(); i++) {
							line = (String) list.get(i);

							if (line.startsWith("#")) {
								writer.println(line);
							} else {
								pos = line.indexOf('=');

								if (pos != -1) {
									key = line.substring(0, pos);

									if (this.containsKey(key)) {
										updateLine = new StringBuffer(key)
												.append('=').append(
														this.getProperty(key));
										writer.println(updateLine.toString());
									} else {
										writer.println(line);
									}
								} else {
									writer.println(line);
								}
							}

						}

						writer.flush();
						writer.close();
						writer = null;
					} catch (FileNotFoundException fnfe) {
						if (log.isErrorEnabled()) {
							log.error("Error occur !", fnfe);
						}
					}

					if (null != writer) {
						writer.close();
						writer = null;
					}

				}

			}

		}
	}

	private ArrayList readLines() {
		ArrayList list = new ArrayList();

		if (null != resource) {

			BufferedReader reader = null;

			try {

				reader = new BufferedReader(new InputStreamReader(this
						.getClass().getResourceAsStream(resource)));

				String line = null;

				while ((line = reader.readLine()) != null) {
					list.add(line);
				}

				reader.close();

				reader = null;

			} catch (IOException ioe) {
				if (log.isErrorEnabled()) {
					log.error("Error occur !", ioe);
				}
			}

			if (null != reader) {
				try {
					reader.close();
				} catch (IOException ioe) {
					if (log.isErrorEnabled()) {
						log.error("Error occur !", ioe);
					}
				}

				reader = null;
			}
		}

		return list;
	}
}