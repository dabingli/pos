package com.cbhb.data.util;

import java.net.URL;
import java.util.Date;

public class UtilTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
        
    }
    
    
    public static void rush(){
        try {
            for (int i = 0; i < 1000; i++) {
                new Thread() {
                    public void run() {
                        try {
                            URL url = new URL(
                                    "http://10.225.1.191:9082/");
                            System.out.println(new Date() + " " + getId() + " "
                                    + url.openConnection().getContentLength());
                        } catch (Exception ee) {
                            ee.printStackTrace();
                        }
                    }
                }.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
