package com.cbhb.data;

import java.util.Map;

public interface MapStyleData {
	public Map toMap();

	public void fromMap(Map map);
}
