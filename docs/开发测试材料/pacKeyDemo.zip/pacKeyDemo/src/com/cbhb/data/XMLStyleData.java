package com.cbhb.data;

public interface XMLStyleData {
	public String toXML();

	public void fromXML(String xmlString);
}
