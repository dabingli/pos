import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.util.Enumeration;


public class CbhbClientKeyImport {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {
			if(null==args || args.length!=4){
				System.out.println("Usage: java CbhbClientKeyImport pfxFileName pfxPwd aliasName priKeyPwd");
				System.exit(0);
			}
			String pfxFile = "d:/BHIBS/keystore/"+args[0];
			String jksFile = "d:/BHIBS/keystore/cbhbclient.jks";
			String newJksFile = "d:/BHIBS/keystore/cbhbclient_new.jks";

			//����jks�ļ���֤�����
			String alias = args[2];

			//����pfx�ļ�ʱ���õ�����
			String pfxPwd = args[1];
			
			//jks�ļ�����
			String jksPwd = "111111";
			
			//pfx�ļ���֤���������
			String inputKeyPwd = pfxPwd;
			
			//����jks�ļ���֤���������
			String outputKeyPwd = args[3];

			char[] nPassword = null;

			KeyStore inputKeyStore = KeyStore.getInstance("PKCS12");
			FileInputStream fis = new FileInputStream(pfxFile);

			if (null != pfxPwd && !"".equals(pfxPwd)) {
				nPassword = pfxPwd.toCharArray();
			}
			inputKeyStore.load(fis, nPassword);

			fis.close();
			fis = null;

			KeyStore outputKeyStore = KeyStore.getInstance("JKS");

			outputKeyStore.load(new FileInputStream(jksFile),
					jksPwd.toCharArray());

			Enumeration enums = inputKeyStore.aliases();

			String keyAlias = (String) enums.nextElement();
			System.out.println("Key alias:" + keyAlias);

			Key key = inputKeyStore.getKey(keyAlias, inputKeyPwd.toCharArray());
			Certificate[] certChain = inputKeyStore
					.getCertificateChain(keyAlias);
			outputKeyStore.setKeyEntry(alias, key, outputKeyPwd.toCharArray(),
					certChain);

			FileOutputStream fos = new FileOutputStream(newJksFile);

			if (null != jksPwd && !"".equals(jksPwd)) {
				nPassword = jksPwd.toCharArray();
			}
			outputKeyStore.store(fos, nPassword);

			fos.close();
			fos = null;
		} catch (Throwable t) {
			t.printStackTrace();
		}

	

	}

}
